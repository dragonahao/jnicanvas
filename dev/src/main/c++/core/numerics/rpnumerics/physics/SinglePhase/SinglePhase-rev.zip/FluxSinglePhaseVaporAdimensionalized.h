#ifndef _FLUXSINGLEPHASEVAPORADIMENSIONALIZED_
#define _FLUXSINGLEPHASEVAPORADIMENSIONALIZED_

#include <stdio.h>
#include <stdlib.h>
#include "FluxFunction.h"

#include "FluxSinglePhaseVaporAdimensionalized_Params.h"
#include "Thermodynamics_Common.h"

class FluxSinglePhaseVaporAdimensionalized : public FluxFunction {
    private:
        // Thermodynamics
        Thermodynamics_Common *thermo;
    protected:
    public:
        FluxSinglePhaseVaporAdimensionalized(const FluxSinglePhaseVaporAdimensionalized &);
        FluxSinglePhaseVaporAdimensionalized(const FluxSinglePhaseVaporAdimensionalized_Params &, Thermodynamics_Common *t);
        FluxSinglePhaseVaporAdimensionalized * clone() const;

        ~FluxSinglePhaseVaporAdimensionalized();

        int jet(const WaveState &u, JetMatrix &m, int degree) const;
};

#endif // _FLUXSINGLEPHASEVAPORADIMENSIONALIZED_

