#ifndef _ACCUMULATIONSINGLEPHASEVAPORADIMENSIONALIZED_
#define _ACCUMULATIONSINGLEPHASEVAPORADIMENSIONALIZED_

#include <stdio.h>
#include <stdlib.h>
#include "AccumulationFunction.h"

#include "AccumulationSinglePhaseVaporAdimensionalized_Params.h"
#include "Thermodynamics_Common.h"

class AccumulationSinglePhaseVaporAdimensionalized : public AccumulationFunction {
    private:
        double phi; // Porosity

        // Thermodynamics
        Thermodynamics_Common *thermo;
    protected:
    public:
        AccumulationSinglePhaseVaporAdimensionalized(const AccumulationSinglePhaseVaporAdimensionalized &);
        AccumulationSinglePhaseVaporAdimensionalized(const AccumulationSinglePhaseVaporAdimensionalized_Params &, Thermodynamics_Common *t);
        AccumulationSinglePhaseVaporAdimensionalized * clone() const;

        ~AccumulationSinglePhaseVaporAdimensionalized();

        int jet(const WaveState &u, JetMatrix &m, int degree) const;
};

#endif // _ACCUMULATIONSINGLEPHASEVAPORADIMENSIONALIZED_

