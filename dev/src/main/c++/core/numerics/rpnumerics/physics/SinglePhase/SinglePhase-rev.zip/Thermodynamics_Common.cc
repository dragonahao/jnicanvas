#include "Thermodynamics_Common.h"

double Thermodynamics_Common::Tref_rock  = 273.15;
double Thermodynamics_Common::Tref_water = 274.3775;
double Thermodynamics_Common::P          = 100.9;

double Thermodynamics_Common::Rock_Cr = 2.029e6;
double Thermodynamics_Common::Cw_     = 4297.0;

// Typical values for the adimensionalization
double Thermodynamics_Common::T_typical_   = 304.63;
double Thermodynamics_Common::Rho_typical_ = 4.22e-3;
double Thermodynamics_Common::U_typical_   = 998.2;
// h_typical_ = Cw_ * (T_typical_ - Tref_water);
double Thermodynamics_Common::h_typical_ = 129994.9925;
double Thermodynamics_Common::rhoW_const = 998.2;

// Some constants for mug
double Thermodynamics_Common::a0 = -1.94760101098783e-6;
double Thermodynamics_Common::a1 =  0.013524080086578;
double Thermodynamics_Common::a2 = -9.043578102452411;
double Thermodynamics_Common::a3 =  1.612763701298628e3;

// some constants for muw
double Thermodynamics_Common::b0 = -0.0123274;
double Thermodynamics_Common::b1 = 27.1038;
double Thermodynamics_Common::b2 = -23527.5;
double Thermodynamics_Common::b3 =  1.01425e7;
double Thermodynamics_Common::b4 = -2.17342e9;
double Thermodynamics_Common::b5 =  1.86935e11;

VLE_Flash_TPCW *Thermodynamics_Common::Flash = (VLE_Flash_TPCW *)0;

// Store the compositions for a fixed temperature
double Thermodynamics_Common::xc_T, Thermodynamics_Common::yw_T;
double Thermodynamics_Common::used_Theta;


void Thermodynamics_Common::SetCompositions(double Theta) {
    if (used_Theta != Theta){
        Flash->flash(Theta2T(Theta), xc_T, yw_T);
        used_Theta = Theta;
    }
    
    return;
}

Thermodynamics_Common::Thermodynamics_Common(double mc, double mw, const char *hsigmaC_name){
    liquid = new JetSinglePhaseLiquid(mc, mw, P);
    vapor  = new JetSinglePhaseVapor(mc, mw, P);

    info_hsigmaC = create_spline(hsigmaC_name, "hsigmaC", P, hsigmaC_);
    ////printf("info_hsigmaC = %d\n", info_hsigmaC);
}

Thermodynamics_Common::~Thermodynamics_Common(){
    delete vapor;
    delete liquid;
}

// Generate a spline
int Thermodynamics_Common::create_spline(const char *name, const char *verify, double P, spline1dinterpolant &spline){
    // Open the file that contains the data needed for the creation of the spline
    FILE *fid;
    fid = fopen(name, "r");
    if (fid == NULL) return SPLINE_ERROR;

    // Read the name of the variable and the pressure and verify them.
    char name_variable[100]; 
    fscanf(fid, "%s", name_variable);

    double Ptest;
    fscanf(fid, "%lf", &Ptest);

    if (strcmp(name_variable, verify) != 0 || Ptest != P){
        fclose(fid);
        return SPLINE_ERROR;
    }

    // Read the number of base functions
    int n_base_func;
    fscanf(fid, "%d", &n_base_func);

    // Read the rest of the data
    int n;
    fscanf(fid, "%d", &n);

    ap::real_1d_array x, y;
    x.setlength(n);
    y.setlength(n);

    double xtemp, ytemp;

    for (int i = 0; i < n; i++){
        fscanf(fid, "%lf %lf", &xtemp, &ytemp);
        x(i) = xtemp;
        y(i) = ytemp;
    }

    // Close the file with the data
    fclose(fid);

    // Generate the spline
    int spline_info;
    spline1dfitreport report;
    spline1dfitcubic(x, y, n, n_base_func,
                     spline_info, 
                     spline, 
                     report);

    if (spline_info > 0) return SPLINE_OK;
    else return SPLINE_ERROR;
}

// hsigmaC
//
int Thermodynamics_Common::hsigmaC_jet(const double Theta, int degree, JetMatrix &hsigmaCj){
    if (degree < 0 || degree > 2) return -1; // ABORTED_PROCEDURE;

    double T = Theta2T(Theta); // T = Theta*T_typical_ + Tref_water
    double h, d_h, d2_h;
    spline1ddiff(hsigmaC_, T, h, d_h, d2_h);

    if (degree >= 0){
        hsigmaCj(0, h/h_typical_);

        if (degree >= 1){
            hsigmaCj(0, 0, d_h*T_typical_/h_typical_);

            if (degree == 2){
                hsigmaCj(0, 0, 0, d2_h*T_typical_*T_typical_/h_typical_);
            }
        }
    }

    return 2; // SUCCESSFUL_PROCEDURE;
}

// Rock Enthalpy Volume
//
int Thermodynamics_Common::RockEnthalpyVol_jet(const double Theta, int degree, JetMatrix &revj){
    if (degree < 0 || degree > 2) return -1; // ABORTED_PROCEDURE

    double T = Theta2T(Theta); // T = Theta*T_typical_ + Tref_water

    if (degree >= 0){
        double rev = Rock_Cr*(T - Tref_rock)/(Rho_typical_*h_typical_);

        revj(0, rev);

        if (degree >= 1){
            double drev_dTheta= Rock_Cr*T_typical_/(Rho_typical_*h_typical_);

            revj(0, 0, drev_dTheta);

            if (degree == 2){
                double d2rev_dTheta2 = 0.0;

                revj(0, 0, 0, d2rev_dTheta2);
            }
        }
    }
    return 2; // SUCCESSFUL_PROCEDURE;
}


// Super Critical Enthalpy Volume
//
int Thermodynamics_Common::SuperCriticEnthalpyVol_jet(const double yw, const double Theta, int degree, JetMatrix &Hsij){
    if (degree < 0 || degree > 2) return -1; // ABORTED_PROCEDURE

    JetMatrix rhosicj(2);
    Rhosic_jet(yw, Theta, degree, rhosicj);

    JetMatrix hsigmaCj(1);
    hsigmaC_jet(Theta, degree, hsigmaCj);

    if (degree >= 0){
        double rhosic  = rhosicj.get(0);
        double hsigmaC = hsigmaCj.get(0);

        double Hsi = rhosic*hsigmaC;

        Hsij(0, Hsi);

        if (degree >= 1){
            double drhosic_dyw     = rhosicj.get(0, 0);
            double drhosic_dTheta  = rhosicj.get(0, 1);
            double dhsigmaC_dTheta = hsigmaCj.get(0, 0);

            double dHsi_dyw    = drhosic_dyw*hsigmaC;
            double dHsi_dTheta = drhosic_dTheta*hsigmaC + rhosic*dhsigmaC_dTheta;

            Hsij(0, 0, dHsi_dyw);
            Hsij(0, 1, dHsi_dTheta);

            if (degree == 2){
                double d2rhosic_dyw2      = rhosicj.get(0, 0, 0);
                double d2rhosic_dywdTheta = rhosicj.get(0, 0, 1);
                double d2rhosic_dThetadyw = rhosicj.get(0, 1, 0);
                double d2rhosic_dTheta2   = rhosicj.get(0, 1, 1);

                double d2hsigmaC_dTheta2  = hsigmaCj.get(0, 0, 0);

                double d2Hsi_dyw2      = d2rhosic_dyw2*hsigmaC;
                double d2Hsi_dywdTheta = d2rhosic_dywdTheta*hsigmaC + drhosic_dyw*dhsigmaC_dTheta;
                double d2Hsi_dThetadyw = d2Hsi_dywdTheta;
                double d2Hsi_dTheta2   = d2rhosic_dTheta2*hsigmaC + 2.0*drhosic_dTheta*dhsigmaC_dTheta +
                                         rhosic*d2hsigmaC_dTheta2;

                Hsij(0, 0, 0, d2Hsi_dyw2);
                Hsij(0, 0, 1, d2Hsi_dywdTheta);
                Hsij(0, 1, 0, d2Hsi_dThetadyw);
                Hsij(0, 1, 1, d2Hsi_dTheta2);
            }
        }
    }
    return 2; // SUCCESSFUL_PROCEDURE;
}

// Hsij is expected to be declared outside as:
//
//    JetMatrix Hsij(1);
//
int Thermodynamics_Common::SuperCriticEnthalpyVol_jet(const double Theta, int degree, JetMatrix &Hsij){
    SetCompositions(Theta);

    JetMatrix OriginalHsij(2);
    int info = SuperCriticEnthalpyVol_jet(yw_T, Theta, degree, OriginalHsij);
    
    if (degree >= 0){
        Hsij(0, OriginalHsij.get(0));
        if (degree >= 1){
            Hsij(0, 0, OriginalHsij.get(0, 1));
            if (degree >= 2){
               Hsij(0, 0, 0, OriginalHsij.get(0, 1, 1));
            }
        }
    }

    return info;
}
//
// End Super Critical Enthalpy Volume




// Pure water enthalpy
//
int Thermodynamics_Common::hW_jet(const double Theta, int degree, JetMatrix &hWj){
    if (degree < 0 || degree > 2) return -1; // ABORTED_PROCEDURE;

    double T = Theta2T(Theta); // T = Theta*T_typical_ + Tref_water

    if (degree >= 0){
        double hW = Cw_*(T - Tref_water);

        hWj(0, hW/h_typical_);

        if (degree >= 1){
            double dhW_dT = Cw_;

            hWj(0, 0, dhW_dT*T_typical_/h_typical_);

            if (degree == 2){
                double d2hW_dT2 = 0.0;

                hWj(0, 0, 0, d2hW_dT2*T_typical_*T_typical_/h_typical_);
            }
        }
    }

    return 2; // SUCCESSFUL_PROCEDURE;
}



// Aqueous Enthalpy Volume
//
int Thermodynamics_Common::AqueousEnthalpyVol_jet(const double xc, const double Theta, int degree, JetMatrix &Haj){
    if (degree < 0 || degree > 2) return -1; // ABORTED_PROCEDURE;

    ////printf("    AqueousEnthalpyVol: xc = %g, Theta = %g\n", xc, Theta);

    JetMatrix rhoawj(2);
    Rhoaw_jet(xc, Theta, degree, rhoawj); //printf("Done:   Rhoaw_jet\n");

    JetMatrix hWj(1);
    hW_jet(Theta, degree, hWj); //printf("Done:   hW_jet\n");

    if (degree >= 0){
        double rhoaw = rhoawj.get(0);
        double hW    = hWj.get(0);

        double Ha = rhoaw*hW;

        Haj.set(0, Ha);

        if (degree >= 1){
            double drhoaw_dxc    = rhoawj.get(0, 0);
            double drhoaw_dTheta = rhoawj.get(0, 1);
            double dhW_dTheta    = hWj.get(0, 0);

            double dHa_dxc    = drhoaw_dxc*hW;
            double dHa_dTheta = drhoaw_dTheta*hW + rhoaw*dhW_dTheta;

            Haj.set(0, 0, dHa_dxc);
            Haj.set(0, 1, dHa_dTheta);

            if (degree == 2){
                double d2rhoaw_dxc2      = rhoawj.get(0, 0, 0);
                double d2rhoaw_dxcdTheta = rhoawj.get(0, 0, 1);
                double d2rhoaw_dThetadxc = rhoawj.get(0, 1, 0);
                double d2rhoaw_dTheta2   = rhoawj.get(0, 1, 1);
                double d2hW_dTheta2      = hWj.get(0, 0, 0);

                double d2Ha_dxc2      = d2rhoaw_dxc2*hW;
                double d2Ha_dxcdTheta = d2rhoaw_dxcdTheta*hW + drhoaw_dxc*dhW_dTheta;
                double d2Ha_dThetadxc = d2Ha_dxcdTheta;
                double d2Ha_dTheta2   = d2rhoaw_dTheta2*hW + 2.0*drhoaw_dTheta*dhW_dTheta + 
                                        rhoaw*d2hW_dTheta2;

                Haj.set(0, 0, 0, d2Ha_dxc2);
                Haj.set(0, 0, 1, d2Ha_dxcdTheta);
                Haj.set(0, 1, 0, d2Ha_dThetadxc);
                Haj.set(0, 1, 1, d2Ha_dTheta2);
            }
        }
    }
    return 2; // SUCCESSFUL_PROCEDURE;
}

// Haj is expected to be declared outside as:
//
//    JetMatrix Haj(1);
//
int Thermodynamics_Common::AqueousEnthalpyVol_jet(const double Theta, int degree, JetMatrix &Haj){
    SetCompositions(Theta);

    JetMatrix OriginalHaj(2);
    int info = SuperCriticEnthalpyVol_jet(xc_T, Theta, degree, OriginalHaj);
    
    if (degree >= 0){
        Haj.set(0, OriginalHaj.get(0));
        if (degree >= 1){
            Haj.set(0, 0, OriginalHaj.get(0, 1));
            if (degree >= 2){
               Haj.set(0, 0, 0, OriginalHaj.get(0, 1, 1));
            }
        }
    }

    return info;
}
//
// End Aqueous Enthalpy Volume

// Rho_{sigma c}
//
int Thermodynamics_Common::Rhosic_jet(const double yw, const double Theta, int degree, JetMatrix &rhosicj){
    if (degree < 0 || degree > 2) return -1; // ABORTED_PROCEDURE;

    double T = Theta2T(Theta); // T = Theta*T_typical_ + Tref_water

    JetMatrix rhosigmacj(2);
    vapor->rhosigmac_jet(yw, T, degree, rhosigmacj);

    if (degree >= 0){
        double rhosigmac = rhosigmacj.get(0);

        double rhosic = rhosigmac/Rho_typical_;

        rhosicj(0, rhosic);

        if (degree >= 1){
            double drhosigmac_dyw = rhosigmacj.get(0, 0);
            double drhosigmac_dT  = rhosigmacj.get(0, 1);

            double drhosic_dyw, drhosic_dTheta;

            drhosic_dyw = drhosigmac_dyw/Rho_typical_;

            drhosic_dTheta = drhosigmac_dT*T_typical_/Rho_typical_;

            rhosicj(0, 0, drhosic_dyw);
            rhosicj(0, 1, drhosic_dTheta);

            if (degree == 2){
                double d2rhosigmac_dyw2  = rhosigmacj.get(0, 0, 0);
                double d2rhosigmac_dywdT = rhosigmacj.get(0, 0, 1);
                double d2rhosigmac_dTdyw = rhosigmacj.get(0, 1, 0);
                double d2rhosigmac_dT2   = rhosigmacj.get(0, 1, 1);

                double d2rhosic_dyw2, d2rhosic_dywdTheta, d2rhosic_dThetadyw, d2rhosic_dTheta2;

                d2rhosic_dyw2      = d2rhosigmac_dyw2/Rho_typical_;
                d2rhosic_dywdTheta = d2rhosigmac_dywdT*T_typical_/Rho_typical_;
                d2rhosic_dThetadyw = d2rhosic_dywdTheta;
                d2rhosic_dTheta2   = d2rhosigmac_dT2*T_typical_*T_typical_/Rho_typical_;

                rhosicj(0, 0, 0, d2rhosic_dyw2);
                rhosicj(0, 0, 1, d2rhosic_dywdTheta);
                rhosicj(0, 1, 0, d2rhosic_dThetadyw);
                rhosicj(0, 1, 1, d2rhosic_dTheta2);
            }
        }
    }
    return 2; // SUCCESSFUL_PROCEDURE;
}

// rhosicj is expected to be declared outside as:
//
//    JetMatrix rhosicj(1);
//
int Thermodynamics_Common::Rhosic_jet(const double Theta, int degree, JetMatrix &rhosicj){
    SetCompositions(Theta);

    JetMatrix Originalrhosicj(2);
    int info = Rhosic_jet(yw_T, Theta, degree, Originalrhosicj);
    
    if (degree >= 0){
        rhosicj(0, Originalrhosicj.get(0));
        if (degree >= 1){
            rhosicj(0, 0, Originalrhosicj.get(0, 1));
            if (degree >= 2){
               rhosicj(0, 0, 0, Originalrhosicj.get(0, 1, 1));
            }
        }
    }

    return info;
}
//
// End Rho_{sigma c}



// Rho_{sigma w}
//
int Thermodynamics_Common::Rhosiw_jet(const double yw, const double Theta, int degree, JetMatrix &rhosiwj){
    if (degree < 0 || degree > 2) return -1; // ABORTED_PROCEDURE;

    double T = Theta2T(Theta); // T = Theta*T_typical_ + Tref_water

    JetMatrix rhosigmawj(2);
    vapor->rhosigmaw_jet(yw, T, degree, rhosigmawj);

    if (degree >= 0){
        double rhosigmaw = rhosigmawj.get(0);

        double rhosiw = rhosigmaw/Rho_typical_;

        rhosiwj(0, rhosiw);

        if (degree >= 1){
            double drhosigmaw_dyw = rhosigmawj.get(0, 0);
            double drhosigmaw_dT  = rhosigmawj.get(0, 1);

            double drhosiw_dyw, drhosiw_dTheta;

            drhosiw_dyw = drhosigmaw_dyw/Rho_typical_;

            drhosiw_dTheta = drhosigmaw_dT*T_typical_/Rho_typical_;

            rhosiwj(0, 0, drhosiw_dyw);
            rhosiwj(0, 1, drhosiw_dTheta);

            if (degree == 2){
                double d2rhosigmaw_dyw2  = rhosigmawj.get(0, 0, 0);
                double d2rhosigmaw_dywdT = rhosigmawj.get(0, 0, 1);
                double d2rhosigmaw_dTdyw = rhosigmawj.get(0, 1, 0);
                double d2rhosigmaw_dT2   = rhosigmawj.get(0, 1, 1);

                double d2rhosiw_dyw2, d2rhosiw_dywdTheta, d2rhosiw_dThetadyw, d2rhosiw_dTheta2;

                d2rhosiw_dyw2      = d2rhosigmaw_dyw2/Rho_typical_;
                d2rhosiw_dywdTheta = d2rhosigmaw_dywdT*T_typical_/Rho_typical_;
                d2rhosiw_dThetadyw = d2rhosiw_dywdTheta;
                d2rhosiw_dTheta2   = d2rhosigmaw_dT2*T_typical_*T_typical_/Rho_typical_;

                rhosiwj(0, 0, 0, d2rhosiw_dyw2);
                rhosiwj(0, 0, 1, d2rhosiw_dywdTheta);
                rhosiwj(0, 1, 0, d2rhosiw_dThetadyw);
                rhosiwj(0, 1, 1, d2rhosiw_dTheta2);
            }
        }
    }
    return 2; // SUCCESSFUL_PROCEDURE;
}

// rhosiwj is expected to be declared outside as:
//
//    JetMatrix rhosiwj(1);
//
int Thermodynamics_Common::Rhosiw_jet(const double Theta, int degree, JetMatrix &rhosiwj){
    SetCompositions(Theta);

    JetMatrix Originalrhosiwj(2);
    int info = Rhosiw_jet(yw_T, Theta, degree, Originalrhosiwj);
    
    if (degree >= 0){
        rhosiwj(0, Originalrhosiwj.get(0));
        if (degree >= 1){
            rhosiwj(0, 0, Originalrhosiwj.get(0, 1));
            if (degree >= 2){
               rhosiwj(0, 0, 0, Originalrhosiwj.get(0, 1, 1));
            }
        }
    }

    return info;
}
//
// End Rho_{sigma w}



// Rho_{a c}
//
int Thermodynamics_Common::Rhoac_jet(const double xc, const double Theta, int degree, JetMatrix &rhoacj){
    if (degree < 0 || degree > 2) return -1; // ABORTED_PROCEDURE;

    double T = Theta2T(Theta); // T = Theta*T_typical_ + Tref_water

    JetMatrix liquid_rhoacj(2);
    liquid->rhoac_jet(xc, T, degree, liquid_rhoacj);

    if (degree >= 0){
        double liquid_rhoac = liquid_rhoacj.get(0);

        double rhoac = liquid_rhoac/Rho_typical_;

        rhoacj(0, rhoac);

        if (degree >= 1){
            double dliquid_rhoac_dxc = liquid_rhoacj.get(0, 0);
            double dliquid_rhoac_dT  = liquid_rhoacj.get(0, 1);

            double drhoac_dxc, drhoac_dTheta;

            drhoac_dxc    = dliquid_rhoac_dxc/Rho_typical_;

            drhoac_dTheta = dliquid_rhoac_dT*T_typical_/Rho_typical_;

            rhoacj(0, 0, drhoac_dxc);
            rhoacj(0, 1, drhoac_dTheta);

            if (degree == 2){
                double d2liquid_rhoac_dxc2  = liquid_rhoacj.get(0, 0, 0);
                double d2liquid_rhoac_dxcdT = liquid_rhoacj.get(0, 0, 1);
                double d2liquid_rhoac_dTdxc = liquid_rhoacj.get(0, 1, 0);
                double d2liquid_rhoac_dT2   = liquid_rhoacj.get(0, 1, 1);

                double d2rhoac_dxc2, d2rhoac_dxcdTheta, d2rhoac_dThetadxc, d2rhoac_dTheta2;

                d2rhoac_dxc2      = d2liquid_rhoac_dxc2/Rho_typical_;
                d2rhoac_dxcdTheta = d2liquid_rhoac_dxcdT*T_typical_/Rho_typical_;
                d2rhoac_dThetadxc = d2rhoac_dxcdTheta;
                d2rhoac_dTheta2   = d2liquid_rhoac_dT2*T_typical_*T_typical_/Rho_typical_;

                rhoacj(0, 0, 0, d2rhoac_dxc2);
                rhoacj(0, 0, 1, d2rhoac_dxcdTheta);
                rhoacj(0, 1, 0, d2rhoac_dThetadxc);
                rhoacj(0, 1, 1, d2rhoac_dTheta2);
            }
        }
    }
    return 2; // SUCCESSFUL_PROCEDURE;
}

// rhoacj is expected to be declared outside as:
//
//    JetMatrix rhoacj(1);
//
int Thermodynamics_Common::Rhoac_jet(const double Theta, int degree, JetMatrix &rhoacj){
    SetCompositions(Theta);

    JetMatrix Originalrhoacj(2);
    int info = Rhoac_jet(xc_T, Theta, degree, Originalrhoacj);
    
    if (degree >= 0){
        rhoacj(0, Originalrhoacj.get(0));
        if (degree >= 1){
            rhoacj(0, 0, Originalrhoacj.get(0, 1));
            if (degree >= 2){
               rhoacj(0, 0, 0, Originalrhoacj.get(0, 1, 1));
            }
        }
    }

    return info;
}
//
// End Rho_{a c}



// Rho_{a w}
//
int Thermodynamics_Common::Rhoaw_jet(const double xc, const double Theta, int degree, JetMatrix &rhoawj){
    if (degree < 0 || degree > 2) return -1; // ABORTED_PROCEDURE;

    double T = Theta2T(Theta); // T = Theta*T_typical_ + Tref_water

    JetMatrix liquid_rhoawj(2); //printf("Before: liquid->rhoaw_jet\n");
    liquid->rhoaw_jet(xc, T, degree, liquid_rhoawj); //printf("Done: liquid->rhoaw_jet\n");

    if (degree >= 0){
        double liquid_rhoaw = liquid_rhoawj.get(0);

        double rhoaw = liquid_rhoaw/Rho_typical_;

        rhoawj.set(0, rhoaw);

        if (degree >= 1){
            double dliquid_rhoaw_dxc = liquid_rhoawj.get(0, 0);
            double dliquid_rhoaw_dT  = liquid_rhoawj.get(0, 1);

            double drhoaw_dxc, drhoaw_dTheta;

            drhoaw_dxc    = dliquid_rhoaw_dxc/Rho_typical_;

            drhoaw_dTheta = dliquid_rhoaw_dT*T_typical_/Rho_typical_;

            rhoawj.set(0, 0, drhoaw_dxc);
            rhoawj.set(0, 1, drhoaw_dTheta);

            if (degree == 2){
                double d2liquid_rhoaw_dxc2  = liquid_rhoawj.get(0, 0, 0);
                double d2liquid_rhoaw_dxcdT = liquid_rhoawj.get(0, 0, 1);
                double d2liquid_rhoaw_dTdxc = liquid_rhoawj.get(0, 1, 0);
                double d2liquid_rhoaw_dT2   = liquid_rhoawj.get(0, 1, 1);

                double d2rhoaw_dxc2, d2rhoaw_dxcdTheta, d2rhoaw_dThetadxc, d2rhoaw_dTheta2;

                d2rhoaw_dxc2      = d2liquid_rhoaw_dxc2/Rho_typical_;
                d2rhoaw_dxcdTheta = d2liquid_rhoaw_dxcdT*T_typical_/Rho_typical_;
                d2rhoaw_dThetadxc = d2rhoaw_dxcdTheta;
                d2rhoaw_dTheta2   = d2liquid_rhoaw_dT2*T_typical_*T_typical_/Rho_typical_;

                rhoawj.set(0, 0, 0, d2rhoaw_dxc2);
                rhoawj.set(0, 0, 1, d2rhoaw_dxcdTheta);
                rhoawj.set(0, 1, 0, d2rhoaw_dThetadxc);
                rhoawj.set(0, 1, 1, d2rhoaw_dTheta2);
            }
        }
    }
    return 2; // SUCCESSFUL_PROCEDURE;
}

// rhoawj is expected to be declared outside as:
//
//    JetMatrix rhoawj(1);
//
int Thermodynamics_Common::Rhoaw_jet(const double Theta, int degree, JetMatrix &rhoawj){
    SetCompositions(Theta);

    JetMatrix Originalrhoawj(2);
    int info = Rhoaw_jet(xc_T, Theta, degree, Originalrhoawj);
    
    if (degree >= 0){
        rhoawj.set(0, Originalrhoawj.get(0));
        if (degree >= 1){
            rhoawj.set(0, 0, Originalrhoawj.get(0, 1));
            if (degree >= 2){
               rhoawj.set(0, 0, 0, Originalrhoawj.get(0, 1, 1));
            }
        }
    }

    return info;
}
//
// End Rho_{a w}



// Viscosity "JETS"
//
void Thermodynamics_Common::muw(double T, double &muw, double &dmuw_dT, double &d2muw_dT2) {

    double inv_T = 1. / T;
    double inv_T2 = inv_T*inv_T;
    double inv_T3 = inv_T2*inv_T;
    double inv_T4 = inv_T3*inv_T;
    double inv_T5 = inv_T4*inv_T;
    double inv_T6 = inv_T5*inv_T;
    double inv_T7 = inv_T6*inv_T;

    muw = (b0 + b1 * inv_T + b2 * inv_T2 + b3 * inv_T3 + b4 * inv_T4 + b5 * inv_T5);
    dmuw_dT = -(b1 * inv_T2 + 2. * b2 * inv_T3 + 3. * b3 * inv_T4 + 4. * b4 * inv_T5 + 5. * b5 * inv_T6);
    d2muw_dT2 = 2. * b1 * inv_T3 + 6. * b2 * inv_T4 + 12. * b3 * inv_T5 + 20. * b4 * inv_T6 + 30. * b5*inv_T7;

    return;
}

void Thermodynamics_Common::inv_muw(double T, double &nuw, double &dnuw_dT, double &d2nuw_dT2) {

    double inv_T = 1. / T;
    double inv_T2 = inv_T*inv_T;
    double inv_T3 = inv_T2*inv_T;
    double inv_T4 = inv_T3*inv_T;
    double inv_T5 = inv_T4*inv_T;
    double inv_T6 = inv_T5*inv_T;
    double inv_T7 = inv_T6*inv_T;

    double muw = (b0 + b1 * inv_T + b2 * inv_T2 + b3 * inv_T3 + b4 * inv_T4 + b5 * inv_T5);
    double dmuw_dT = -(b1 * inv_T2 + 2. * b2 * inv_T3 + 3. * b3 * inv_T4 + 4. * b4 * inv_T5 + 5. * b5 * inv_T6);
    double d2muw_dT2 = 2. * b1 * inv_T3 + 6. * b2 * inv_T4 + 12. * b3 * inv_T5 + 20. * b4 * inv_T6 + 30. * b5*inv_T7;

    nuw = 1. / muw;
    double inv_muw2 = nuw*nuw;
    double inv_muw3 = inv_muw2*nuw;

    dnuw_dT = -dmuw_dT*inv_muw2;
    d2nuw_dT2 = 2. * dmuw_dT * dmuw_dT * inv_muw3 - d2muw_dT2*inv_muw2;

    return;
}

void Thermodynamics_Common::mug(double T, double &mug, double &dmug_dT, double &d2mug_dT2) {

    mug = 1e-6 * (a0 * T * T * T + a1 * T * T + a2 * T + a3);
    dmug_dT = 1e-6 * (3. * a0 * T * T + 2. * a1 * T + a2);
    d2mug_dT2 = 1e-6 * (6. * a0 + 2. * a1);

    return;
}

void Thermodynamics_Common::inv_mug(double T, double &nug, double &dnug_dT, double &d2nug_dT2) {

    double nug_den = 1. / (a0 * T * T * T + a1 * T * T + a2 * T + a3);
    nug = 1. / (1e-6 * (a0 * T * T * T + a1 * T * T + a2 * T + a3));
    double nug_denSQ = nug_den*nug_den;

    double dmug_dT = 3. * a0 * T * T + 2. * a1 * T + a2;
    double dmug_dTSQ = dmug_dT*dmug_dT;

    dnug_dT = -1e6 * nug_denSQ*dmug_dT;
    d2nug_dT2 = 1e6 * (2. * nug_denSQ * nug_den * dmug_dTSQ - nug_denSQ * (6. * T * a0 + 2. * a1));

    return;
}
