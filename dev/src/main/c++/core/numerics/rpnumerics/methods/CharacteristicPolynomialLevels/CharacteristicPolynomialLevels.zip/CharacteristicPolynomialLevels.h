#ifndef _CHARACTERISTICPOLYNOMIALLEVELS_
#define _CHARACTERISTICPOLYNOMIALLEVELS_

#include "ImplicitFunction.h"

class CharacteristicPolynomialLevels : public ImplicitFunction {
    private:
    protected:
    public:

        // Eigenvalues

        // Discriminant

        // Discriminant derivative
};

#endif // _CHARACTERISTICPOLYNOMIALLEVELS_

