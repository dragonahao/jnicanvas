#include "ExplicitHugoniot.h"

ExplicitHugoniot::ExplicitHugoniot(const Boundary *bb) : b(bb){
}

ExplicitHugoniot::~ExplicitHugoniot(){
}

void ExplicitHugoniot::curve(const RealVector &ref, std::vector<Curve> &curve){
    referencepoint = ref;

//    PolarPlot::plot(&f, (void*)this, 0.0, M_PI, 1000, b, curve);
    ParametricPlot::plot(&f, &f_asymptote, (void*)this, phi_begin, phi_end, 50, b, curve);

    return;
}

RealVector ExplicitHugoniot::f(void *obj, double phi){
    return ((ExplicitHugoniot*)obj)->fobj(phi);
}

bool ExplicitHugoniot::f_asymptote(void *obj, const RealVector &p, const RealVector &q){
    ExplicitHugoniot *eh = (ExplicitHugoniot*)obj;

    RealVector p_minus_ref = p - eh->referencepoint;
    RealVector q_minus_ref = q - eh->referencepoint;

    double prod = norm(p_minus_ref)*norm(q_minus_ref);

    return std::abs(prod + p_minus_ref*q_minus_ref) < std::abs(prod)*1e-1;
}

