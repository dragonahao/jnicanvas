#include "HugoniotContinuation3D2D.h"

// Trivial initialization. It is assumed that the reference point and the initial point
// are one and the same (in).
//
// TODO: Accumulations should be able to declare if they are trivial or not.
//       If a trivial accumulation is used, see below to modify some parts accordingly.
//
int HugoniotContinuation3D2D::find_initial_direction(const RealVector &in, const RealVector &hint_direction, int fam, RealVector &initial_direction){
    int n = in.size();

    DoubleMatrix A(n, n), B(n, n);
    f->fill_with_jet(n, in.components(), 1, 0, A.data(), 0);
    g->fill_with_jet(n, in.components(), 1, 0, B.data(), 0);
    //if (g != 0) g->fill_with_jet(n, in.components(), 1, 0, B.data(), 0);
    
    RealVector r;

    // TODO: If the accumulation is trivial this method should
    //       be replaced by the one that only takes one matrix as input.
    //
    int info;
    info = Eigen::eig(n, A.data(), B.data(), fam, r); // TODO: Verify if lambda is complex, return error. Make similar for eigenvalue. Error not fatal in that case.
    
    //if (g != 0) info = Eigen::eig(n, A.data(), B.data(), fam, r);
    //else        info = Eigen::eig(n, A.data(), fam, r);

//    A.print();
//    B.print();

    //std::cout << "r = " << r << std::endl;

    if (info == COMPLEX_EIGENVALUE) return HUGONIOTCONTINUATION3D2D_INITIALIZE_ERROR; 

    if (r*hint_direction > 0.0) initial_direction = r;
    else                        initial_direction = -r;

    return HUGONIOTCONTINUATION3D2D_INITIALIZED_OK;
}

// Shockspeed. Not used right now. TODO: Create a version that uses the ReferencePoint.
// 
double HugoniotContinuation3D2D::shockspeed(const FluxFunction *fp, const AccumulationFunction *gp, const RealVector &Up,
                                            const FluxFunction *fm, const AccumulationFunction *gm, const RealVector &Um){

    int n = Up.size();

    RealVector Fp(n), Fm(n), Gp(n), Gm(n);

    fp->fill_with_jet(n, Up.components(), 0, Fp.components(), 0, 0);
    fm->fill_with_jet(n, Um.components(), 0, Fm.components(), 0, 0);

    gp->fill_with_jet(n, Up.components(), 0, Gp.components(), 0, 0);
    gm->fill_with_jet(n, Um.components(), 0, Gm.components(), 0, 0);

    double s = 0.0, d = 0.0;

    for (int i = 0; i < n; i++){
        double dd = Gp(i) - Gm(i);

        s += (Fp(i) - Fm(i))*dd;

        d += dd*dd;
    }

    return s/d; 
}

// TODO: Create a jet_H(int j, const RealVector &p, double &H, RealVector &nabla_H);
//       to consolidate jet_H1 and jet_H2.
//
// From here onwards this is Helmut's. It works exclusively for carbon & water.
//
void HugoniotContinuation3D2D::jet_H1(const RealVector &p, double &H1, RealVector &nabla_H1){
    RealVector F(3), G(3);
    DoubleMatrix A(3, 3), B(3, 3);

    f->fill_with_jet(3, p.components(), 1, F.components(), A.data(), 0);
    g->fill_with_jet(3, p.components(), 1, G.components(), B.data(), 0);

    // [F] & [G]
    //
    RealVector diff_F = F - ref.F;
    RealVector diff_G = G - ref.G;

    // H1
    //
    H1 = diff_F(0)*diff_G(2) - diff_F(2)*diff_G(0);

    // nablaH1
    //
    nabla_H1.resize(3);

    for (int i = 0; i < 3; i++) nabla_H1(i) = A(0, i)*diff_G(2) + B(2, i)*diff_F(0) - A(2, i)*diff_G(0) - B(0, i)*diff_F(2);

    return;
}

// Nabla H2. 
//
void HugoniotContinuation3D2D::jet_H2(const RealVector &p, double &H2, RealVector &nabla_H2) {
    RealVector F(3), G(3);
    DoubleMatrix A(3, 3), B(3, 3);

    f->fill_with_jet(3, p.components(), 1, F.components(), A.data(), 0);
    g->fill_with_jet(3, p.components(), 1, G.components(), B.data(), 0);

    // [F] & [G]
    //
    RealVector diff_F = F - ref.F;
    RealVector diff_G = G - ref.G;

    // H2
    //
    H2 = diff_F(1)*diff_G(2) - diff_F(2)*diff_G(1);

    // nablaH2
    //
    nabla_H2.resize(3);

    for (int i = 0; i < 3; i++) nabla_H2(i) = A(1, i)*diff_G(2) + B(2, i)*diff_F(1) - A(2, i)*diff_G(1) - B(1, i)*diff_F(2);

    return; 
}

void HugoniotContinuation3D2D::jet_Hugoniot(const RealVector &p, RealVector &H, DoubleMatrix &nablaH){
    int n = p.size();

//    RealVector F(n), G(n);
//    DoubleMatrix A(n, n), B(n, n);

//    f->fill_with_jet(n, p.components(), 1, F.components(), A.data(), 0);
//    g->fill_with_jet(n, p.components(), 1, G.components(), B.data(), 0);

//    // [F] & [G]
//    //
//    RealVector diff_F = F - ref.F;
//    RealVector diff_G = G - ref.G;

//    H.resize(n - 1);
//    nablaH.resize(n - 1, n);

//    int indx[2] = {0, 1};

//    for (int i = 0; i < n - 1; i++){
//        int j = (i == n - 2) ? 0 : i + 1;
//        
//        j = indx[i];

//        //H(i) = diff_F(i)*diff_G(j) - diff_F(j)*diff_G(i);
//        H(i) = diff_F(i)*diff_G(2) - diff_F(2)*diff_G(i);

//        for (int k = 0; k < n - 1; k++) nablaH(k, i) = A(i, k)*diff_G(2) + B(j, k)*diff_F(i) - A(j, k)*diff_G(i) - B(i, k)*diff_F(j);
//    }

    H.resize(2);

    RealVector nH1, nH2;

    jet_H1(p, H(0), nH1); //normalize(nH1);
    jet_H2(p, H(1), nH2); //normalize(nH2);

    nablaH.resize(n - 1, n);
    for (int i = 0; i < 3; i++){
        nablaH(0, i) = nH1(i);
        nablaH(1, i) = nH2(i);
    }  

    return;
}

// Later on v1 and v2 will be replaced by DoubleMatrix &hyperplane.
//
int HugoniotContinuation3D2D::fill_hyperplane(const RealVector &origin, RealVector &v1, RealVector &v2){
    double H1, H2; // TODO: Create a version of jet_H1 and jet_H2 that does not return H1 and H2.

    jet_H1(origin, H1, v1);
    normalize(v1);
    
    jet_H2(origin, H2, v2);
    normalize(v2);

    // TODO: This below MAYBE will be necessary.
    /*orthonormalize();*/

    return HUGONIOTCONTINUATION3D2D_HYPERPLANE_OK;
}

int HugoniotContinuation3D2D::fill_hyperplane(const RealVector &origin, DoubleMatrix &hyperplane){
    RealVector H;
    jet_Hugoniot(origin, H, hyperplane);

    // Normalize by rows.
    //
    for (int i = 0; i < hyperplane.rows(); i++){
        double n = 0.0;
        for (int j = 0; j < hyperplane.cols(); j++) n += hyperplane(i, j)*hyperplane(i, j);

        double inv_n = 1.0/sqrt(n);

        for (int j = 0; j < hyperplane.cols(); j++) hyperplane(i, j) *= inv_n;
    }


    return HUGONIOTCONTINUATION3D2D_HYPERPLANE_OK;
}

int HugoniotContinuation3D2D::fill_Hugoniot_direction(const RealVector &previous_direction, const RealVector &v1, const RealVector &v2, RealVector &Hugoniot_direction){
    Hugoniot_direction = vector_product(v1, v2);
    
    double norm_Hugoniot_direction = norm(Hugoniot_direction);
    
    // TODO: The 1e-4 below should be variable and should come from outside somehow.
    //
    if (norm_Hugoniot_direction < 1e-4) return HUGONIOTCONTINUATION3D2D_DIRECTION_ERROR;
    else {
        double inv = 1.0/norm_Hugoniot_direction;
        Hugoniot_direction = Hugoniot_direction*inv;
    
        if (Hugoniot_direction*previous_direction < 0.0) Hugoniot_direction = -Hugoniot_direction;

        return HUGONIOTCONTINUATION3D2D_DIRECTION_OK;
    }
}

int HugoniotContinuation3D2D::fill_Hugoniot_direction(const RealVector &previous_direction, const DoubleMatrix &hyperplane, RealVector &Hugoniot_direction){
    // The lines below will be generalized later on.
//    int cols = hyperplane.cols();
//    RealVector v1(cols), v2(cols);
//    for (int i = 0; i < cols; i++){
//        v1(i) = hyperplane(0, i);
//        v2(i) = hyperplane(1, i);
//    }

    Hugoniot_direction = vector_product(matrix_row(hyperplane, 0), matrix_row(hyperplane, 1));
//    Hugoniot_direction = vector_product(v1, v2);
    
    double norm_Hugoniot_direction = norm(Hugoniot_direction);
    
    // TODO: The 1e-4 below should be variable and should come from outside somehow.
    //
    if (norm_Hugoniot_direction < 1e-4) return HUGONIOTCONTINUATION3D2D_DIRECTION_ERROR;
    else {
        double inv = 1.0/norm_Hugoniot_direction;
        Hugoniot_direction = Hugoniot_direction*inv;
    
        if (Hugoniot_direction*previous_direction < 0.0) Hugoniot_direction = -Hugoniot_direction;

        return HUGONIOTCONTINUATION3D2D_DIRECTION_OK;
    }
}

// TODO: a1 and a2 will be consolidated into a RealVector and v1 and v2 will be consolidated into a DoubleMatrix.
//       Something like old_hyperplane_point + V*a;
//
//RealVector HugoniotContinuation3D2D::hyperplane_mapping(const RealVector &old_hyperplane_point, double a1, const RealVector &v1, double a2, const RealVector &v2){
RealVector HugoniotContinuation3D2D::hyperplane_mapping(double a1, const RealVector &v1, double a2, const RealVector &v2){
//    return old_hyperplane_point + a1*v1 + a2*v2; // Compute the new hyperplane point.
    return a1*v1 + a2*v2; // Compute the new hyperplane point.
}

RealVector HugoniotContinuation3D2D::hyperplane_mapping(const RealVector &a, const DoubleMatrix &hyperplane){
    return transpose(hyperplane)*a; // Compute the new hyperplane point.
}

// TODO: URGENT: Create a friend function in RealVector to deal with DoubleMatrix*RealVector.
//
void HugoniotContinuation3D2D::Newton_system_for_Hugoniot(const RealVector &p, const RealVector &v1, const RealVector &v2, DoubleMatrix &Newton_matrix, RealVector &error){

    // TODO: Consolidate jet_H1 and jet_H2 so that H1 & H2 are stored in a vector and nablaH1, nablaH2 into a DoubleMatrix.
    double H1, H2;
    RealVector nablaH1, nablaH2;
    
    jet_H1(p, H1, nablaH1);
    jet_H2(p, H2, nablaH2);
    
    error.resize(2);
    error(0) = H1;
    error(1) = H2;

    Newton_matrix.resize(2, 2);
    Newton_matrix(0, 0) = nablaH1*v1;
    Newton_matrix(0, 1) = nablaH1*v2;
    Newton_matrix(1, 0) = nablaH2*v1;
    Newton_matrix(1, 1) = nablaH2*v2;

    // Was:
    /*
    N[0] = H1;
    N[1] = H2;

    DN[0] = dotprod(3, nablaH1, v1);
    DN[1] = dotprod(3, nablaH1, v2);
    DN[2] = dotprod(3, nablaH2, v1);
    DN[3] = dotprod(3, nablaH2, v2);
    */
    
    return;
}

void HugoniotContinuation3D2D::Newton_system_for_Hugoniot(const RealVector &p, const DoubleMatrix &hyperplane, DoubleMatrix &Newton_matrix, RealVector &error){
    DoubleMatrix nablaH;

    jet_Hugoniot(p, error, nablaH);

    Newton_matrix = nablaH*transpose(hyperplane);

    return;
}

int HugoniotContinuation3D2D::Newton_in_hyperplane(const RealVector &origin, const RealVector &v1, const RealVector &v2, RealVector &Hugoniot_intersection){
    
    int m = origin.size() - 1;
    RealVector correction(RealVector::zeroes(m));
    
    int max_number_iterations = 10; // TODO: This parameter should receive a default value in the ctor.
    int iterations = 0;
    
    double min_norm = 1e-6; // TODO: This parameter should receive a default value in the ctor.
    
    double norm_correction = 0.0;
    
    RealVector hyperplane_point = origin; // ??????? E origin ou zero?
    
    do {
        DoubleMatrix Newton_matrix;
        RealVector error;
        
        Newton_system_for_Hugoniot(hyperplane_point, v1, v2, Newton_matrix, error);
        std::cout << "Newton_in_hyperplane. hyperplane_point = " << hyperplane_point << ", v1 = " << v1 << ", v2 = " << v2 << std::endl;
	std::cout << "Newton_matrix = " << std::endl;
	Newton_matrix.print();
	std:cout << "error = " << error << std::endl;        
        
        int info_correction = solve(Newton_matrix, error, correction);
        std::cout << "correction = " << correction << std::endl;
        
        if (info_correction == REALVECTOR_SOLVE_LINEAR_SYSTEM_ERROR) return REALVECTOR_SOLVE_LINEAR_SYSTEM_ERROR;
        
        // Update: new hyper
        //
//        hyperplane_point = hyperplane_point - hyperplane_mapping(origin, correction(0), v1, correction(1), v2); // ???? Aqui temos duvidas. Marchesin & Morante. 
        hyperplane_point = hyperplane_point - hyperplane_mapping(correction(0), v1, correction(1), v2); // ???? Aqui temos duvidas. Marchesin & Morante. 
        std::cout << "New hyperplane point: " <<hyperplane_point << std::endl; 
        
        iterations++;
        
        norm_correction = norm(correction);
        
    } while (iterations < max_number_iterations && norm_correction > min_norm && norm_correction < 10.0); // TODO: 10.0 was fixed here, it must be fine-tuned, perhaps it should become a member.
    
    if (iterations >= max_number_iterations) return HUGONIOTCONTINUATION3D2D_NEWTON_ERROR;
    
    // Output.
    //
    Hugoniot_intersection = hyperplane_point;
    std::cout << "Iterations: " << iterations << ", norm_correction = " << norm_correction << ", Hug. inters. = " << Hugoniot_intersection << std::endl;
    
    return HUGONIOTCONTINUATION3D2D_NEWTON_OK;
}

int HugoniotContinuation3D2D::Newton_in_hyperplane(const RealVector &origin, const DoubleMatrix &hyperplane, RealVector &Hugoniot_intersection){
    
    int m = origin.size() - 1;
    RealVector correction(RealVector::zeroes(m));
    
    int max_number_iterations = 10; // TODO: This parameter should receive a default value in the ctor.
    int iterations = 0;
    
    double min_norm = 1e-6; // TODO: This parameter should receive a default value in the ctor.
    
    double norm_correction = 0.0;
    
    RealVector hyperplane_point = origin; // ??????? E origin ou zero?
    
    do {
        DoubleMatrix Newton_matrix;
        RealVector error;

//        Newton_system_for_Hugoniot(hyperplane_point, v1, v2, Newton_matrix, error);
        Newton_system_for_Hugoniot(hyperplane_point, hyperplane, Newton_matrix, error);

        int info_correction = solve(Newton_matrix, error, correction);
        
        if (info_correction == REALVECTOR_SOLVE_LINEAR_SYSTEM_ERROR) return REALVECTOR_SOLVE_LINEAR_SYSTEM_ERROR;
        
        // Update the point in the hyperplane.
        //
        //hyperplane_point = hyperplane_point - hyperplane_mapping(correction(0), v1, correction(1), v2); // ???? Aqui temos duvidas. Marchesin & Morante. 

        hyperplane_point = hyperplane_point - transpose(hyperplane)*correction;

        iterations++;
        
        norm_correction = norm(correction);
        
    } while (iterations < max_number_iterations && norm_correction > min_norm && norm_correction < 10.0); // TODO: 10.0 was fixed here, it must be fine-tuned, perhaps it should become a member.
    
    if (iterations >= max_number_iterations) return HUGONIOTCONTINUATION3D2D_NEWTON_ERROR;
    
    // Output.
    //
    Hugoniot_intersection = hyperplane_point;
    
    return HUGONIOTCONTINUATION3D2D_NEWTON_OK;
}

int HugoniotContinuation3D2D::Newton_step(const RealVector &previous_point, double &shift, const RealVector &previous_direction,
                                          RealVector &v1, RealVector &v2, RealVector &Hugoniot_intersection){

    int shift_iterations = 0;
    int max_number_shift_iterations = 10;
    int info_newton;

    shift *= 2.0;

    do {
        shift *= 0.5;
        shift_iterations++;

        // Find the origin of the new plane
        //
        RealVector hyperplane_origin = previous_point + shift*previous_direction;
        
        int info_fill_hyperplane = fill_hyperplane(hyperplane_origin, v1, v2);
        
        if (info_fill_hyperplane == HUGONIOTCONTINUATION3D2D_HYPERPLANE_ERROR){
            return HUGONIOTCONTINUATION3D2D_HYPERPLANE_ERROR;
        } 
        
        // Find the intersection of the Hugoniot curve with the hyperplane.
        //
        info_newton = Newton_in_hyperplane(hyperplane_origin, v1, v2, Hugoniot_intersection);

    } while (shift_iterations < max_number_shift_iterations && info_newton == HUGONIOTCONTINUATION3D2D_NEWTON_ERROR);

    // TODO: Here, if convergence is not achieved, the shift should be
    //       reduced. When the moment comes this region will go
    //       inside a do-while loop.
    //
    if (info_newton == HUGONIOTCONTINUATION3D2D_NEWTON_ERROR){
        return HUGONIOTCONTINUATION3D2D_NEWTON_ERROR;
    } 
    else return HUGONIOTCONTINUATION3D2D_NEWTON_STEP_OK;
}

int HugoniotContinuation3D2D::Newton_step(const RealVector &previous_point, double &shift, const RealVector &previous_direction,
                                          DoubleMatrix &hyperplane, RealVector &Hugoniot_intersection){

    int shift_iterations = 0;
    int max_number_shift_iterations = 10;
    int info_newton;

    shift *= 2.0;

    do {
        shift *= 0.5;
        shift_iterations++;

        // Find the origin of the new plane
        //
        RealVector hyperplane_origin = previous_point + shift*previous_direction;
        
        // The hyperplane where the Hugoniot Locus point will be found via Newton.
        // (The rows are the basis' vectors).
        //
        int info_fill_hyperplane = fill_hyperplane(hyperplane_origin, hyperplane);
        
        if (info_fill_hyperplane == HUGONIOTCONTINUATION3D2D_HYPERPLANE_ERROR){
            return HUGONIOTCONTINUATION3D2D_HYPERPLANE_ERROR;
        } 
        
        // Find the intersection of the Hugoniot curve with the hyperplane.
        //
        info_newton = Newton_in_hyperplane(hyperplane_origin, hyperplane, Hugoniot_intersection);

    } while (shift_iterations < max_number_shift_iterations && info_newton == HUGONIOTCONTINUATION3D2D_NEWTON_ERROR);

    // TODO: Here, if convergence is not achieved, the shift should be
    //       reduced. When the moment comes this region will go
    //       inside a do-while loop.
    //
    if (info_newton == HUGONIOTCONTINUATION3D2D_NEWTON_ERROR){
        return HUGONIOTCONTINUATION3D2D_NEWTON_ERROR;
    } 
    else return HUGONIOTCONTINUATION3D2D_NEWTON_STEP_OK;
}

// TODO: Eliminate const ReferencePoint &r that will move up to curve.
int HugoniotContinuation3D2D::curve_engine(const ReferencePoint &r, const RealVector &in, int fam, const RealVector &initial_direction, 
                                           RealVector &final_direction, std::vector<RealVector> &shockcurve){

    // Move this to curve.
    ref = r;

    // This is the distance between two consecutive planes.
    // TODO: Make this step adaptative.
    //
    double default_shift = 0.005, shift; // The order of magnitude of f and g must be known, so as to declare a correct value for default_shift.

    RealVector previous_point = in;
    RealVector previous_direction = initial_direction;

    while (true){
        shift = default_shift;
        
        RealVector Hugoniot_intersection;
        RealVector Hugoniot_direction;

        DoubleMatrix hyperplane;
        int info_Newton_step = Newton_step(previous_point, shift, previous_direction, hyperplane, Hugoniot_intersection);

        if (info_Newton_step == HUGONIOTCONTINUATION3D2D_NEWTON_ERROR){
            std::cout << "    Curve_engine. Error in Newton_step." << std::endl;
            return HUGONIOTCONTINUATION3D2D_NEWTON_ERROR;
        } 
        
        // Find the hyperplane.
        //
        fill_hyperplane(Hugoniot_intersection, hyperplane);

        // Find the direction of the Hugoniot curve.
        //
//        int info_fill_Hugoniot_direction = fill_Hugoniot_direction(previous_direction, v1, v2, Hugoniot_direction); // TODO: v1 and v2 will be replaced by a DoubleMatrix.
        int info_fill_Hugoniot_direction = fill_Hugoniot_direction(previous_direction, hyperplane, Hugoniot_direction); // TODO: v1 and v2 will be replaced by a DoubleMatrix.
        
        if (info_fill_Hugoniot_direction == HUGONIOTCONTINUATION3D2D_DIRECTION_ERROR){
            std::cout << "    Curve_engine. Error in fill_Hugoniot_direction." << std::endl;
            return HUGONIOTCONTINUATION3D2D_DIRECTION_ERROR;
        }
        
        // TODO: If the angle between Hugoniot_direction and previous_direction is large reduce the shift. 
        //       If we have success without changing shift for a few steps, increase shift.
                
        // Something's missing here...
        previous_point     = Hugoniot_intersection;
        previous_direction = Hugoniot_direction;
        
        // CHECK THE STOP CRITERIA!!!!!!!!!!
        if (!boundary->inside(Hugoniot_intersection)){
//            fill_hyperplane(Hugoniot_intersection, v1, v2);
//            fill_Hugoniot_direction(previous_direction, v1, v2, final_direction);

            fill_hyperplane(Hugoniot_intersection, hyperplane);
            fill_Hugoniot_direction(previous_direction, hyperplane, final_direction);

            std::cout << "    Curve_engine. Point " << Hugoniot_intersection << " lies outside the domain." << std::endl;
            return HUGONIOTCONTINUATION3D2D_CURVE_OK;
        }
        
        // Add the point to the curve and update the last correct final_direction.
        //
        shockcurve.push_back(Hugoniot_intersection);
    }

    return HUGONIOTCONTINUATION3D2D_CURVE_OK;
}

HugoniotContinuation3D2D::HugoniotContinuation3D2D(const FluxFunction *ff, const AccumulationFunction *gg, const Boundary *bb){
    f = ff;
    g = gg;
    boundary = bb;
}

HugoniotContinuation3D2D::~HugoniotContinuation3D2D(){
}

