#ifndef _HUGONIOTCONTINUATION3D2D_
#define _HUGONIOTCONTINUATION3D2D_

#include <iostream>

#include "FluxFunction.h"
#include "AccumulationFunction.h"
#include "Boundary.h"
#include "RealVector.h"
#include "ReferencePoint.h"
#include "DoubleMatrix.h"
#include "eigen.h"

#ifndef HUGONIOTCONTINUATION3D2D_INITIALIZE_NO
#define HUGONIOTCONTINUATION3D2D_INITIALIZE_NO 0
#endif

#ifndef HUGONIOTCONTINUATION3D2D_INITIALIZE_YES
#define HUGONIOTCONTINUATION3D2D_INITIALIZE_YES 1
#endif

#ifndef HUGONIOTCONTINUATION3D2D_INITIALIZED_OK
#define HUGONIOTCONTINUATION3D2D_INITIALIZED_OK 10
#endif

#ifndef HUGONIOTCONTINUATION3D2D_INITIALIZE_ERROR
#define HUGONIOTCONTINUATION3D2D_INITIALIZE_ERROR 11
#endif

#ifndef HUGONIOTCONTINUATION3D2D_CURVE_OK
#define HUGONIOTCONTINUATION3D2D_CURVE_OK 20
#endif

#ifndef HUGONIOTCONTINUATION3D2D_CURVE_ERROR
#define HUGONIOTCONTINUATION3D2D_CURVE_ERROR 21
#endif

#ifndef HUGONIOTCONTINUATION3D2D_HYPERPLANE_OK
#define HUGONIOTCONTINUATION3D2D_HYPERPLANE_OK 30
#endif

#ifndef HUGONIOTCONTINUATION3D2D_HYPERPLANE_ERROR
#define HUGONIOTCONTINUATION3D2D_HYPERPLANE_ERROR 31
#endif

#ifndef HUGONIOTCONTINUATION3D2D_DIRECTION_OK
#define HUGONIOTCONTINUATION3D2D_DIRECTION_OK 40
#endif

#ifndef HUGONIOTCONTINUATION3D2D_DIRECTION_ERROR
#define HUGONIOTCONTINUATION3D2D_DIRECTION_ERROR 41
#endif

#ifndef HUGONIOTCONTINUATION3D2D_NEWTON_OK
#define HUGONIOTCONTINUATION3D2D_NEWTON_OK 50
#endif

#ifndef HUGONIOTCONTINUATION3D2D_NEWTON_ERROR
#define HUGONIOTCONTINUATION3D2D_NEWTON_ERROR 51
#endif

#ifndef HUGONIOTCONTINUATION3D2D_NEWTON_STEP_OK
#define HUGONIOTCONTINUATION3D2D_NEWTON_STEP_OK 60
#endif

#ifndef HUGONIOTCONTINUATION3D2D_NEWTON_STEP_ERROR
#define HUGONIOTCONTINUATION3D2D_NEWTON_STEP_ERROR 61
#endif

class HugoniotContinuation3D2D {
    private:
    public:
        const FluxFunction *f;
        const AccumulationFunction *g;
        const Boundary *boundary;

        ReferencePoint ref;

        int find_initial_direction(const RealVector &in, const RealVector &hint_direction, int fam, RealVector &initial_direction);

        double shockspeed(const FluxFunction *fp, const AccumulationFunction *gp, const RealVector &Up,
                          const FluxFunction *fm, const AccumulationFunction *gm, const RealVector &Um);

        void jet_H1(const RealVector &p, double &H1, RealVector &nabla_H1);
        void jet_H2(const RealVector &p, double &H2, RealVector &nabla_H2);

        void jet_Hugoniot(const RealVector &p, RealVector &H, DoubleMatrix &nablaH) ; 

        int fill_hyperplane(const RealVector &origin, RealVector &v1, RealVector &v2);

        int fill_Hugoniot_direction(const RealVector &previous_direction, const RealVector &v1, const RealVector &v2, RealVector &Hugoniot_direction);

        RealVector hyperplane_mapping(double a1, const RealVector &v1, double a2, const RealVector &v2);

        void Newton_system_for_Hugoniot(const RealVector &p, const RealVector &v1, const RealVector &v2, DoubleMatrix &Newton_matrix, RealVector &error);

        int Newton_in_hyperplane(const RealVector &origin, const RealVector &v1, const RealVector &v2, RealVector &Hugoniot_intersection);

        int Newton_step(const RealVector &previous_point, double &shift, const RealVector &previous_direction,
                        RealVector &v1, RealVector &v2, RealVector &Hugoniot_intersection);

        int curve_engine(const ReferencePoint &r, const RealVector &in, int fam, const RealVector &initial_direction, 
                         RealVector &final_direction, std::vector<RealVector> &shockcurve);
    public:
        HugoniotContinuation3D2D(const FluxFunction *ff, const AccumulationFunction *gg, const Boundary *bb);
        virtual ~HugoniotContinuation3D2D();

//        int curve(const ReferencePoint &r, const RealVector &in, int fam, int increment, bool initialize, const RealVector *direction, std::vector<RealVector> &curve);
};

#endif // _HUGONIOTCONTINUATION3D2D_

