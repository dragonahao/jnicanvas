#ifndef _HUGONIOTCONTINUATION_NDND_
#define _HUGONIOTCONTINUATION_NDND_

#include <iostream>

#include "FluxFunction.h"
#include "AccumulationFunction.h"
#include "Boundary.h"
#include "RealVector.h"
#include "ReferencePoint.h"
#include "DoubleMatrix.h"
#include "eigen.h"

#ifndef HUGONIOTCONTINUATION_NDND_INITIALIZE_NO
#define HUGONIOTCONTINUATION_NDND_INITIALIZE_NO 0
#endif

#ifndef HUGONIOTCONTINUATION_NDND_INITIALIZE_YES
#define HUGONIOTCONTINUATION_NDND_INITIALIZE_YES 1
#endif

#ifndef HUGONIOTCONTINUATION_NDND_INITIALIZED_OK
#define HUGONIOTCONTINUATION_NDND_INITIALIZED_OK 10
#endif

#ifndef HUGONIOTCONTINUATION_NDND_INITIALIZE_ERROR
#define HUGONIOTCONTINUATION_NDND_INITIALIZE_ERROR 11
#endif

#ifndef HUGONIOTCONTINUATION_NDND_CURVE_OK
#define HUGONIOTCONTINUATION_NDND_CURVE_OK 20
#endif

#ifndef HUGONIOTCONTINUATION_NDND_CURVE_ERROR
#define HUGONIOTCONTINUATION_NDND_CURVE_ERROR 21
#endif

#ifndef HUGONIOTCONTINUATION_NDND_HYPERPLANE_OK
#define HUGONIOTCONTINUATION_NDND_HYPERPLANE_OK 30
#endif

#ifndef HUGONIOTCONTINUATION_NDND_HYPERPLANE_ERROR
#define HUGONIOTCONTINUATION_NDND_HYPERPLANE_ERROR 31
#endif

#ifndef HUGONIOTCONTINUATION_NDND_DIRECTION_OK
#define HUGONIOTCONTINUATION_NDND_DIRECTION_OK 40
#endif

#ifndef HUGONIOTCONTINUATION_NDND_DIRECTION_ERROR
#define HUGONIOTCONTINUATION_NDND_DIRECTION_ERROR 41
#endif

#ifndef HUGONIOTCONTINUATION_NDND_NEWTON_OK
#define HUGONIOTCONTINUATION_NDND_NEWTON_OK 50
#endif

#ifndef HUGONIOTCONTINUATION_NDND_NEWTON_ERROR
#define HUGONIOTCONTINUATION_NDND_NEWTON_ERROR 51
#endif

#ifndef HUGONIOTCONTINUATION_NDND_NEWTON_STEP_OK
#define HUGONIOTCONTINUATION_NDND_NEWTON_STEP_OK 60
#endif

#ifndef HUGONIOTCONTINUATION_NDND_NEWTON_STEP_ERROR
#define HUGONIOTCONTINUATION_NDND_NEWTON_STEP_ERROR 61
#endif

#ifndef HUGONIOTCONTINUATION_NDND_SET_BIFURCATION_PLANE_OK
#define HUGONIOTCONTINUATION_NDND_SET_BIFURCATION_PLANE_OK 70
#endif

#ifndef HUGONIOTCONTINUATION_NDND_SET_BIFURCATION_PLANE_ERROR
#define HUGONIOTCONTINUATION_NDND_SET_BIFURCATION_PLANE_ERROR 71
#endif

#ifndef HUGONIOTCONTINUATION_NDND_NEAR_COINCIDENCE_CURVE
#define HUGONIOTCONTINUATION_NDND_NEAR_COINCIDENCE_CURVE 81
#endif

#ifndef SQRT_TWO
#define SQRT_TWO 1.41421356237
#endif

#ifndef MAX_COS_ANGLE
#define MAX_COS_ANGLE (0.96)
#endif

class HugoniotContinuation_nDnD {
    private:
    public:
        const FluxFunction *f;
        const AccumulationFunction *g;
        const Boundary *boundary;

        ReferencePoint ref;
        
        double bifurcation_space_coordinate;
        int bifurcation_space_coordinate_index;
        bool there_is_a_bifurcation_space;
//        DoubleMatrix bifurcation_space_basis;

        int find_initial_direction(const RealVector &in, const RealVector &hint_direction, int fam, RealVector &initial_direction);

        double shockspeed(const FluxFunction *fp, const AccumulationFunction *gp, const RealVector &Up,
                          const FluxFunction *fm, const AccumulationFunction *gm, const RealVector &Um);

//        void jet_H1(const RealVector &p, double &H1, RealVector &nabla_H1);
//        void jet_H2(const RealVector &p, double &H2, RealVector &nabla_H2);

//        void jet_H(const RealVector &p, int i, double &H, RealVector &nablaH);

        void jet_Hugoniot(const RealVector &p, RealVector &H, DoubleMatrix &nablaH) ; 

        int fill_hyperplane(const RealVector &origin, DoubleMatrix &hyperplane);

        int fill_Hugoniot_direction(const RealVector &previous_direction, const DoubleMatrix &hyperplane, RealVector &Hugoniot_direction);

        int find_continuation_direction(const RealVector &Hugoniot_point, const RealVector &hint, RealVector &Hugoniot_direction);

        void Newton_system_for_Hugoniot(const RealVector &p, const DoubleMatrix &hyperplane, DoubleMatrix &Newton_matrix, RealVector &error);

        int Newton_in_hyperplane(const RealVector &origin, const DoubleMatrix &hyperplane, RealVector &Hugoniot_intersection);

        int Newton_step(const RealVector &previous_point, double &step_size, int &number_of_steps_with_unchanged_size, const RealVector &previous_direction,
                        DoubleMatrix &hyperplane, RealVector &Hugoniot_intersection);

        int curve_engine(const RealVector &in, const RealVector &initial_direction, 
                         RealVector &final_direction, std::vector<RealVector> &shockcurve, int &edge);

        // Initial step_size. 
        // This user should access to this member. However, a default value must be set when the curve is created.
        // The only problem with the user setting this value is that the class must know it happened.
//        double initial_step_size;
    public:
        HugoniotContinuation_nDnD(const FluxFunction *ff, const AccumulationFunction *gg, const Boundary *bb);
        virtual ~HugoniotContinuation_nDnD();

        void set_reference_point(const ReferencePoint &r);
        int set_bifurcation_space_coordinate(int Theta_index);
        bool reference_point_near_coincidence();

        int curve(std::vector< std::vector<RealVector> > &curve);

        // TODO: The user must be allowed to modify a parameter that the constructor sets to MAX_COS_ANGLE.
};

#endif // _HUGONIOTCONTINUATION_NDND_
