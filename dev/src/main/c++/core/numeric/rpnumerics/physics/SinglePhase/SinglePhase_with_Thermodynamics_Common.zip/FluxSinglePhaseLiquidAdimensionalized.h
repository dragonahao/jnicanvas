#ifndef _FLUXSINGLEPHASELIQUIDADIMENSIONALIZED_
#define _FLUXSINGLEPHASELIQUIDADIMENSIONALIZED_

#include <stdio.h>
#include <stdlib.h>
#include "FluxFunction.h"

#include "FluxSinglePhaseLiquidAdimensionalized_Params.h"
#include "Thermodynamics_Common.h"

class FluxSinglePhaseLiquidAdimensionalized : public FluxFunction {
    private:
        // Thermodynamics
        Thermodynamics_Common *thermo;
    protected:
    public:
        FluxSinglePhaseLiquidAdimensionalized(const FluxSinglePhaseLiquidAdimensionalized &);
        FluxSinglePhaseLiquidAdimensionalized(const FluxSinglePhaseLiquidAdimensionalized_Params &, Thermodynamics_Common *t);
        FluxSinglePhaseLiquidAdimensionalized * clone() const;

        ~FluxSinglePhaseLiquidAdimensionalized();

        int jet(const WaveState &u, JetMatrix &m, int degree) const;
};

#endif // _FLUXSINGLEPHASELIQUIDADIMENSIONALIZED_

