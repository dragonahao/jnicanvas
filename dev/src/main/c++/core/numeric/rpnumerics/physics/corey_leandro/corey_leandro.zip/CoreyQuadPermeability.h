/*
 * IMPA - Fluid Dynamics Laboratory
 *
 * RPn Project
 *
 * @(#) CoreyQuadPermeability.h
 */

#ifndef _CoreyQuadPermeability_H
#define _CoreyQuadPermeability_H

/*
 * ---------------------------------------------------------------
 * Includes:
 */
#include <math.h>
#include "CoreyQuadPermParams.h"

/*
 * ---------------------------------------------------------------
 * Definitions:
 */


class CoreyQuadPermeability{
    
private:
    CoreyQuadPermParams * params_;

    double cnw_, cng_, cno_;
    double lw_, lg_,lo_;
    
    // The following flags allow to have negative saturations.
    bool NegativeWaterSaturation, NegativeGasSaturation, NegativeOilSaturation;

    
public:
    
    CoreyQuadPermeability(const CoreyQuadPermParams & params);
    CoreyQuadPermeability(const CoreyQuadPermeability & );
    virtual ~CoreyQuadPermeability();
    
    const CoreyQuadPermParams & params() const ;

    //int PermeabilityWater_jet(const WaveState &u, int degree, JetMatrix &kwj) const;
    //int PermeabilityOil_jet(const WaveState &u, int degree, JetMatrix &koj) const;
    //int PermeabilityGas_jet(const WaveState &u, int degree, JetMatrix &kgj) const;

    int ZeroPermeabilityWater_jet(const WaveState &u, int degree, JetMatrix &kwj) const;
    int QuadPermeabilityWater_jet(const WaveState &u, int degree, JetMatrix &kwj) const;
    int ZeroPermeabilityOil_jet(const WaveState &u, int degree, JetMatrix &koj) const;
    int QuadPermeabilityOil_jet(const WaveState &u, int degree, JetMatrix &koj) const;
    int ZeroPermeabilityGas_jet(const WaveState &u, int degree, JetMatrix &kgj) const;
    int QuadPermeabilityGas_jet(const WaveState &u, int degree, JetMatrix &kgj) const;

};


inline const CoreyQuadPermParams & CoreyQuadPermeability::params() const{ return *params_; }

#endif //! _CoreyQuadPermeability_H

