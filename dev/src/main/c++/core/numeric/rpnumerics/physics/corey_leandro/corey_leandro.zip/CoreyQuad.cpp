#include "CoreyQuad.h"

CoreyQuad::CoreyQuad(const CoreyQuad_Params *param) : FluxFunction(*param), perm(0) {//TODO USAR OS ELEMENTOS DO VETOR GUARDADO EM FLUXFUNCTION

}

CoreyQuad::CoreyQuad(const CoreyQuad_Params *param, const CoreyQuadPermeability *p) : FluxFunction(*param), perm(p) {//TODO USAR OS ELEMENTOS DO VETOR GUARDADO EM FLUXFUNCTION

}

CoreyQuad * CoreyQuad::clone() const {
    return new CoreyQuad(*this);
}

CoreyQuad::CoreyQuad(const CoreyQuad & copy) : FluxFunction(copy.fluxParams()), perm(copy.perm) {

}

CoreyQuad::~CoreyQuad() {
}

int CoreyQuad::jet(const WaveState &w, JetMatrix &m, int degree) const {

    double grw = fluxParams().component(0);
    double grg = fluxParams().component(1);
    double gro = fluxParams().component(2);

    double muw = fluxParams().component(3);
    double mug = fluxParams().component(4);
    double muo = fluxParams().component(5);

    double vel = fluxParams().component(6);

    JetMatrix kwj(2);
    JetMatrix koj(2);
    JetMatrix kgj(2);

    // ---
    double sw = w(0);
    double so = w(1);
    double sg = 1.0 - sw - so;

    double cnw_ = params()->component(0);
    double cng_ = params()->component(1);
    double cno_ = params()->component(2);

    double swcnw = sw - cnw_;
    if (swcnw <= 0.)
        perm->ZeroPermeabilityWater_jet(w, degree, kwj);
    else
        perm->QuadPermeabilityWater_jet(w, degree, kwj);

    double socno = so - cno_;
    if (socno <= 0.)
        perm->ZeroPermeabilityOil_jet(w, degree, koj);
    else
        perm->QuadPermeabilityOil_jet(w, degree, koj);

    double sgcng = sg - cng_;
    if (sgcng <= 0.)
        perm->ZeroPermeabilityGas_jet(w, degree, kgj);
    else
        perm->QuadPermeabilityGas_jet(w, degree, kgj);


    double Grwo = grw - gro;
    double Grwg = grw - grg;
    double Grow = -1. * Grwo;
    double Grog = gro - grg;
    // ---

    
    //perm->PermeabilityWater_jet(u, degree, kwj);
    //perm->PermeabilityOil_jet(u, degree, koj);
    //perm->PermeabilityGas_jet(u, degree, kgj);
    

    double lkw = kwj.get(0) / muw; // Water mobility
    double lko = koj.get(0) / muo; // Oil mobility
    double lkg = kgj.get(0) / mug; // Gas mobility

    double lk = lkw + lko + lkg; // Total mobility


    if (degree >= 0) {

        double fw , fo ;

        if (Grwo == 0.  &&  Grwg == 0.) {
            fw = (lkw / lk) * vel;
        }
        else {
            fw = (lkw / lk) * (vel + lko * Grwo + lkg * Grwg);
        }

        if (Grow == 0.  &&  Grog == 0.) {
            fo = (lko / lk) * vel;
        }
        else {
            fo = (lko / lk) * (vel + lkw * Grow + lkg * Grog);
        }

        m.set(0, fw);
        m.set(1, fo);


        if (degree >= 1) {
            double tw = 0., to = 0.;
            double dtodso = 0., dtodsw = 0., dtwdso = 0., dtwdsw = 0.;
            double dfw_dsw = 0., dfw_dso = 0., dfo_dsw = 0., dfo_dso = 0.;

            double dkw_dsw = kwj.get(0, 0);
            double dkw_dso = kwj.get(0, 1);
            
            double dko_dsw = koj.get(0, 0);
            double dko_dso = koj.get(0, 1);
            
            double dkg_dsw = kgj.get(0, 0);
            double dkg_dso = kgj.get(0, 1);



		double d2kw_dsw2   = kwj.get(0, 0, 0);
                double d2kw_dswdso = kwj.get(0, 0, 1);
                double d2kw_dsodsw = kwj.get(0, 1, 0);
                double d2kw_dso2   = kwj.get(0, 1, 1);
                
                double d2ko_dsw2   = koj.get(0, 0, 0);
                double d2ko_dswdso = koj.get(0, 0, 1);
                double d2ko_dsodsw = koj.get(0, 1, 0);
                double d2ko_dso2   = koj.get(0, 1, 1);
                
                double d2kg_dsw2   = kgj.get(0, 0, 0);
                double d2kg_dswdso = kgj.get(0, 0, 1);
                double d2kg_dsodsw = kgj.get(0, 1, 0);
                double d2kg_dso2   = kgj.get(0, 1, 1);


        
            double ldkw_dsw = dkw_dsw / muw;
            double ldko_dsw = dko_dsw / muo;
            double ldkg_dsw = dkg_dsw / mug;
            double ldk_dsw = ldkw_dsw + ldko_dsw + ldkg_dsw;

            double ldkw_dso = dkw_dso / muw;
            double ldko_dso = dko_dso / muo;
            double ldkg_dso = dkg_dso / mug;
            double ldk_dso = ldkw_dso + ldko_dso + ldkg_dso;

            double ld2kw_dsw2 = d2kw_dsw2 / muw;
            double ld2kw_dswso = d2kw_dswdso / muw;
            double ld2kw_dso2 = d2kw_dso2 / muw;

            double ld2ko_dsw2 = d2ko_dsw2 / muo;
            double ld2ko_dswso = d2ko_dswdso / muo;
            double ld2ko_dso2 = d2kw_dso2 / muo;

            double ld2kg_dsw2 = d2kg_dsw2 / mug;
            double ld2kg_dswso = d2kg_dswdso / mug;
            double ld2kg_dso2 = d2kg_dso2 / mug;

            double zgwdsw = (lk * ldkw_dsw - lkw * ldk_dsw) / (lk * lk);
            double zgwdso = (lk * ldkw_dso - lkw * ldk_dso) / (lk * lk);
            double zgodsw = (lk * ldko_dsw - lko * ldk_dsw) / (lk * lk);
            double zgodso = (lk * ldko_dso - lko * ldk_dso) / (lk * lk);


            if (Grwo == 0.  &&  Grwg == 0.) {
	        tw      = vel;
	        dtwdso  = 0.;
	        dtwdsw  = 0.;
	        dfw_dsw = zgwdsw * tw;
	        dfw_dso = zgwdso * tw;
            }
            else {
 	        tw = vel + lko * Grwo + lkg * Grwg;
	        dtwdso = Grwo * ldko_dso + Grwg * ldkg_dso;
	        dtwdsw = ldko_dsw * Grwo + Grwg * ldkg_dsw;
	        dfw_dsw = zgwdsw * tw + (lkw / lk) * dtwdsw;
	        dfw_dso = zgwdso * tw + (lkw / lk) * dtwdso;
            }


            if (Grow == 0.  &&  Grog == 0.) {
                to = vel;
	        dtodso = 0.;
	        dtodsw = 0.;
	        dfo_dsw = zgodsw * to;
	        dfo_dso = zgodso * to;
            }
            else {
                to = vel + lkw * Grow + lkg * Grog;
	        dtodso = Grog * ldkg_dso;
	        dtodsw = Grow * ldkw_dsw + Grog * ldkg_dso;
	        dfo_dsw = zgodsw * to + (lko / lk) * dtodsw;
	        dfo_dso = zgodso * to + (lko / lk) * dtodso;
            }


            m.set(0, 0, dfw_dsw);
            m.set(0, 1, dfw_dso);
            m.set(1, 0, dfo_dsw);
            m.set(1, 1, dfo_dso);


            if (degree == 2) {
                double dtwdww = 0., dtwdwo = 0., dtwdoo = 0.;
                double dtodww = 0., dtodwo = 0., dtodoo = 0.;
	        double d2fw_dsw2 = 0., d2fw_dswso = 0., d2fw_dsosw = 0., d2fw_dso2 = 0.;
	        double d2fo_dsw2 = 0., d2fo_dswso = 0., d2fo_dsosw = 0., d2fo_dso2 = 0.;

                /*double d2kw_dsw2   = kwj.get(0, 0, 0);
                double d2kw_dswdso = kwj.get(0, 0, 1);
                double d2kw_dsodsw = kwj.get(0, 1, 0);
                double d2kw_dso2   = kwj.get(0, 1, 1);
                
                double d2ko_dsw2   = koj.get(0, 0, 0);
                double d2ko_dswdso = koj.get(0, 0, 1);
                double d2ko_dsodsw = koj.get(0, 1, 0);
                double d2ko_dso2   = koj.get(0, 1, 1);
                
                double d2kg_dsw2   = kgj.get(0, 0, 0);
                double d2kg_dswdso = kgj.get(0, 0, 1);
                double d2kg_dsodsw = kgj.get(0, 1, 0);
                double d2kg_dso2   = kgj.get(0, 1, 1);*/

	    double ld2k_dsw2 = ld2kw_dsw2 + ld2ko_dsw2 + ld2kg_dsw2;
            double ld2k_dswso = ld2kw_dswso + ld2ko_dswso + ld2kg_dswso;
            double ld2k_dso2 = ld2kw_dso2 + ld2ko_dso2 + ld2kg_dso2;

                double zgfww = ((lk * ld2kw_dsw2 - lkw * ld2k_dsw2) / lk - 2. * ldk_dsw * zgwdsw) / lk;
                double zgfwo = ((lk * ld2kw_dswso - lkw * ld2k_dswso) / lk - (ldk_dsw * zgwdso + zgwdsw * ldk_dso)) / lk;
                double zgfoo = ((lk * ld2kw_dso2 - lkw * ld2k_dso2) / lk - 2. * ldk_dso * zgwdso) / lk;
                double zggww = ((lk * ld2ko_dsw2 - lko * ld2k_dsw2) / lk - 2. * ldk_dsw * zgodsw) / lk;
                double zggwo = ((lk * ld2ko_dswso - lko * ld2k_dswso) / lk - (ldk_dsw * zgodso + zgodsw * ldk_dso)) / lk;
                double zggoo = ((lk * ld2ko_dso2 - lko * ld2k_dso2) / lk - 2. * ldk_dso * zgodso) / lk;


                if (Grwo == 0.  &&  Grwg == 0.) {
		    d2fw_dsw2  = zgfww * tw;
		    d2fw_dswso = zgfwo * tw;
		    d2fw_dsosw = zgfwo * tw;
		    d2fw_dso2  = zgfoo * tw;
                }
	        else {
	            dtwdww = ld2ko_dsw2 * Grwo + Grwg * ld2kg_dsw2;
		    dtwdwo = ld2ko_dswso * Grwo + Grwg * ld2kg_dswso;
		    dtwdoo = ld2ko_dso2 * Grwo + Grwg * ld2kg_dso2;

		    d2fw_dsw2  = zgfww * tw + 2. * zgwdsw * dtwdsw + (lkw / lk) * dtwdww;
		    d2fw_dswso = zgfwo * tw + zgwdsw * dtwdso + zgwdso * dtwdsw + (lkw / lk) * dtwdwo;
		    d2fw_dsosw = zgfwo * tw + zgwdsw * dtwdso + zgwdso * dtwdsw + (lkw / lk) * dtwdwo;
		    d2fw_dso2  = zgfoo * tw + 2. * zgwdso * dtwdso + (lkw / lk) * dtwdoo;
	        }

                if (Grow == 0.  &&  Grog == 0.) {
		    d2fo_dsw2  = zggww * to;
		    d2fo_dswso = zggwo * to;
		    d2fo_dsosw = zggwo * to;
		    d2fo_dso2  = zggoo * to;
	        }
	        else {
		    dtodww = ld2kw_dsw2 * Grow + Grog * ld2kg_dsw2;
		    dtodwo = Grog * ld2kg_dswso;
		    dtodoo = Grog * ld2kg_dso2;

		    d2fo_dsw2  = zggww * to + 2. * zgodsw * dtodsw + (lko / lk) * dtodww;
   		    d2fo_dswso = zggwo * to + zgodso * dtodsw + zgodsw * dtodso + (lko / lk) * dtodwo;
		    d2fo_dsosw = zggwo * to + zgodso * dtodsw + zgodsw * dtodso + (lko / lk) * dtodwo;
		    d2fo_dso2  = zggoo * to + 2. * zgodso * dtodso + (lko / lk) * dtodoo;
	        }

                m.set(0, 0, 0, d2fw_dsw2);
                m.set(0, 0, 1, d2fw_dswso);
                m.set(0, 1, 0, d2fw_dsosw);
                m.set(0, 1, 1, d2fw_dso2);

                m.set(1, 0, 0, d2fo_dsw2);
                m.set(1, 0, 1, d2fo_dswso);
                m.set(1, 1, 0, d2fo_dsosw);
                m.set(1, 1, 1, d2fo_dso2);

            }

        } //endif >= 1

    } //endif >= 0

    return 2; //SUCCESSFUL_PROCEDURE;
}


