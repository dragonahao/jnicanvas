// Arquivo a testar. PCR 03/06/2014


/*
 * IMPA - Fluid Dynamics Laboratory
 *
 * RPn Project
 *
 * @(#) StoneFluxFunction.cc
 */

/*
 * ---------------------------------------------------------------
 * Includes:
 */
#include "StoneFluxFunction.h"

/*
 * ---------------------------------------------------------------
 * Definitions:
 */

StoneFluxFunction::StoneFluxFunction(const StoneParams & params, const StonePermParams & permParams ) : FluxFunction(FluxParams(params.params())), perm_(new StonePermeability(permParams)) {

    // TODO: Change from reference to pointers to allow real time change of parameters. Gracias.
    grw = params.component(0);
    grg = params.component(1);
    gro = params.component(2);

    muw = params.component(3);
    mug = params.component(4);
    muo = params.component(5);

    vel = params.component(6);
}


StoneFluxFunction::StoneFluxFunction(const StoneFluxFunction & copy) : FluxFunction(copy.fluxParams()),perm_(new StonePermeability(copy.perm())) {

    grw = fluxParams().component(0);
    grg = fluxParams().component(1);
    gro = fluxParams().component(2);

    muw = fluxParams().component(3);
    mug = fluxParams().component(4);
    muo = fluxParams().component(5);

    vel = fluxParams().component(6);
}

RpFunction * StoneFluxFunction::clone() const {
    return new StoneFluxFunction(*this);
}

StoneFluxFunction::~StoneFluxFunction() {
    delete perm_;
}

int StoneFluxFunction::jet(const WaveState &w, JetMatrix &m, int degree) const {
    JetMatrix water_jet(2, 1);
    perm_->PermeabilityWater_jet(w, degree, water_jet);

    JetMatrix gas_jet(2, 1);
    perm_->PermeabilityGas_jet(w, degree, gas_jet);

    JetMatrix oil_jet(2, 1);
    perm_->PermeabilityOil_jet(w, degree, oil_jet);

    if (degree >= 0){
        double muw_inv = 1.0 / muw;
        double muo_inv = 1.0 / muo;
        double mug_inv = 1.0 / mug;

        double lkw = water_jet.get(0) * muw_inv;       // Water mobility
        double lko = oil_jet.get(0)   * muo_inv;       // Oil mobility
        double lkg = gas_jet.get(0)   * mug_inv;       // Gas mobility

        double lk = lkw + lko + lkg;                   // Total mobility

        double fw = lkw/lk;
        double fo = lko/lk;

        double water_term = vel;
        double oil_term   = vel;

        // Added by Morante, see if this is correct or what.
        //
        double rho_wo, rho_wg, rho_og;

        if (gravity_) {
            rho_wo = grw - gro;
            rho_wg = grw - grg;
            rho_og = gro - grg;

            water_term += lko * rho_wo + lkg * rho_wg;
            oil_term   += lkg * rho_og - lkw * rho_wo;
        }
        else {
            // Added by Morante, see if this is correct or what.
            //
            rho_wo = rho_wg = rho_og = 0.0;
        }

        m.set(0, fw * water_term );  // Fw
        m.set(1, fo * oil_term   );  // Fo

        if (degree >= 1){
           double lk_inv;

           double ldkw_dsw = water_jet.get(0,0) * muw_inv;
           double ldko_dsw = oil_jet.get(0, 0)  * muo_inv;
           double ldkg_dsw = gas_jet.get(0, 0)  * mug_inv;
           double ldk_dsw  = ldkw_dsw + ldko_dsw + ldkg_dsw;

           double ldkw_dso = water_jet.get(0,1) * muw_inv;
           double ldko_dso = oil_jet.get(0, 1)  * muo_inv;
           double ldkg_dso = gas_jet.get(0, 1)  * mug_inv;
           double ldk_dso  = ldkw_dso + ldko_dso + ldkg_dso;

           double to = vel;
           double tw = vel;

           double dtodso = 0.0;
           double dtodsw = 0.0;
           double dtwdso = 0.0;
           double dtwdsw = 0.0;

           if (gravity_) {
               to += lkg * rho_og - lkw * rho_wo;
               tw += lko * rho_wo + lkg * rho_wg;

               dtodso += rho_og * ldkg_dso;
               dtodsw += rho_og * ldkg_dso - rho_wo * ldkw_dsw;
               dtwdso += rho_wo * ldko_dso + rho_wg * ldkg_dso;
               dtwdsw += ldko_dsw * rho_wo + rho_wg * ldkg_dsw;
           }

           double zgwdsw = ( ldkw_dsw  -  fw * ldk_dsw ) * lk_inv;
           double zgwdso = ( ldkw_dso  -  fw * ldk_dso ) * lk_inv;
           double zgodsw = ( ldko_dsw  -  fo * ldk_dsw ) * lk_inv;
           double zgodso = ( ldko_dso  -  fo * ldk_dso ) * lk_inv;

           m.set(0, 0, zgwdsw * tw + fw * dtwdsw); // dfw_dsw
           m.set(0, 1, zgwdso * tw + fw * dtwdso); // dfw_dso
           m.set(1, 0, zgodsw * to + fo * dtodsw); // dfo_dsw
           m.set(1, 1, zgodso * to + fo * dtodso); // dfo_dso

           if (degree == 2){
               double ld2kw_dsw2  = water_jet.get(0,0,0) * muw_inv;
               double ld2kw_dswso = water_jet.get(0,0,1) * muw_inv;
               double ld2kw_dso2  = water_jet.get(0,1,1) * muw_inv;

               double ld2ko_dsw2  = oil_jet.get(0,0,0) * muo_inv;
               double ld2ko_dswso = oil_jet.get(0,0,1) * muo_inv;
               double ld2ko_dso2  = oil_jet.get(0,1,1) * muo_inv;     // Was: double ld2ko_dso2= d2kw_dso2/ muo;

               double ld2kg_dsw2  = gas_jet.get(0,0,0) * mug_inv;
               double ld2kg_dswso = gas_jet.get(0,0,1) * mug_inv;
               double ld2kg_dso2  = gas_jet.get(0,1,1) * mug_inv;

               double ld2k_dsw2  = ld2kw_dsw2  + ld2ko_dsw2  + ld2kg_dsw2; 
               double ld2k_dswso = ld2kw_dswso + ld2ko_dswso + ld2kg_dswso;
               double ld2k_dso2  = ld2kw_dso2  + ld2ko_dso2  + ld2kg_dso2;

               double zgfww =( ( ld2kw_dsw2  - fw * ld2k_dsw2  ) -  2. * ldk_dsw * zgwdsw ) * lk_inv;
               double zgfwo =( ( ld2kw_dswso - fw * ld2k_dswso ) -  (ldk_dsw * zgwdso + zgwdsw * ldk_dso) ) * lk_inv;
               double zgfoo =( ( ld2kw_dso2  - fw * ld2k_dso2  ) -  2. * ldk_dso * zgwdso ) * lk_inv;
               double zggww =( ( ld2ko_dsw2  - fo * ld2k_dsw2  ) -  2. * ldk_dsw * zgodsw ) * lk_inv;
               double zggwo =( ( ld2ko_dswso - fo * ld2k_dswso ) -  (ldk_dsw * zgodso + zgodsw * ldk_dso) ) * lk_inv;
               double zggoo =( ( ld2ko_dso2  - fo * ld2k_dso2  ) -  2. * ldk_dso * zgodso ) * lk_inv;

               double dtwdww = 0.0;
               double dtwdwo = 0.0;
               double dtwdoo = 0.0;
               double dtodww = 0.0;
               double dtodwo = 0.0;
               double dtodoo = 0.0;

               if (gravity_) {
                   dtwdww += ld2ko_dsw2  * rho_wo + rho_wg * ld2kg_dsw2;
                   dtwdwo += ld2ko_dswso * rho_wo + rho_wg * ld2kg_dswso;
                   dtwdoo += ld2ko_dso2  * rho_wo + rho_wg * ld2kg_dso2;
                   dtodww += rho_og * ld2kg_dsw2  - ld2kw_dsw2 * rho_wo;
                   dtodwo += rho_og * ld2kg_dswso;
                   dtodoo += rho_og * ld2kg_dso2;
               }

               m.set(0, 0, 0, zgfww * tw + 2. * zgwdsw * dtwdsw + fw * dtwdww);              // d2fw_dsw2;
               m.set(0, 0, 1, zgfwo * tw + zgwdsw * dtwdso + zgwdso * dtwdsw + fw * dtwdwo); // d2fw_dswso;
               m.set(0, 1, 0, m.get(0, 0, 1));                                               // d2fw_dsosw;
               m.set(0, 1, 1, zgfoo * tw + 2. * zgwdso*dtwdso + fw * dtwdoo);                // d2fw_dso2;

               m.set(1, 0, 0, zggww * to + 2. * zgodsw * dtodsw + fo * dtodww);              // d2fo_dsw2;
               m.set(1, 0, 1, zggwo * to + zgodso * dtodsw + zgodsw * dtodso + fo * dtodwo); // d2fo_dswso;
               m.set(1, 1, 0, m.get(1, 0, 1));                                               // d2fo_dsosw;
               m.set(1, 1, 1, zggoo * to + 2. * zgodso * dtodso + fo * dtodoo);              // d2fo_dso2;

            }
        }
        else return 0;
    }
    return 2; //SUCCESSFUL_PROCEDURE;
}




