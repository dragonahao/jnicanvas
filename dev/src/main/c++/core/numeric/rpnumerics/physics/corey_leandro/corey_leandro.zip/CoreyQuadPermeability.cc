/*
 * IMPA - Fluid Dynamics Laboratory
 *
 * RPn Project
 *
 * @(#) CoreyQuadPermeability.cc
 */

/*
 * ---------------------------------------------------------------
 * Includes:
 */
#include "CoreyQuadPermeability.h"
#include <iostream>

using namespace std;

/*
 * ---------------------------------------------------------------
 * Definitions:
 */

/** For the Corey model it is implemented the one in:
 *     LaForce and Johns (2004) - "Analytical theory for three-phase partially miscible
 *                                 flow in ternary systems", SPE 89438
 *  Even if in the next papers one allows the gas critical saturation to be differente
 *  to zero. LaForce and Jonhs is the only paper that sets for saturations bigger than 1
 *  minus the two other residual saturations, the actual saturation as the endpoint
 *  permeability of such phase.
 *
 *  There is also a small references to this kind of permeabilities in:
 *     Juanes and Patzek (2002) - "Three-phase displacement theory: An improved
 *                                 description of relative permeabilities", SPE 77539
 *  or:
 *     Foulser, Goodyear and Sims (1992) - "Two and three phase relative permeabilities
 *                                          at high capillary numbers", CIM 92-72
 *
 *  A basic comparation for the construction is made in:
 *     Parker & Lenhard (1990) - "Determining three-phase permeability-saturation-pressure
 *                                relations from two-phase system measurements", JPSE 4
 *
 **/



CoreyQuadPermeability::CoreyQuadPermeability(const CoreyQuadPermParams & params) : params_(new CoreyQuadPermParams(params)) {

    cnw_ = params_->component(0);
    cng_ = params_->component(1);
    cno_ = params_->component(2);

    lw_ = params_->component(3);
    lg_ = params_->component(4);
    lo_ = params_->component(5);

    
    /*if (params_->component(17) == 0.0)
        NegativeWaterSaturation = false;
    else
        NegativeWaterSaturation = true;

    if (params_->component(18) == 0.0)
        NegativeGasSaturation = false;
    else
        NegativeGasSaturation = true;

    if (params_->component(19) == 0.0)
        NegativeOilSaturation = false;
    else
        NegativeOilSaturation = true;*/


}

CoreyQuadPermeability::CoreyQuadPermeability(const CoreyQuadPermeability & copy) : params_(new CoreyQuadPermParams(copy.params())) {

    cnw_ = copy.cnw_;
    cng_ = copy.cng_;
    cno_ = copy.cno_;

    lw_ = copy.lw_;
    lg_ = copy.lg_;
    lo_ = copy.lo_;

}

CoreyQuadPermeability::~CoreyQuadPermeability() {
    delete params_;
}


// --------------------------------------------------------------------------------------------------------
// kwj is expected to be declared outside as:
//
//    JetMatrix kwj(2); // Check if this is true, it could be simply JetMatrix kwj(1); if depends only on sw.
//
int CoreyQuadPermeability::ZeroPermeabilityWater_jet(const WaveState &u, int degree, JetMatrix &kwj) const {

    if (degree >= 0){

	kwj.set(0, 0.);

        if (degree >= 1) {

	    kwj.set(0, 0, 0.);
            kwj.set(0, 1, 0.);
            
            if (degree >= 2) {

                kwj.set(0, 0, 0, 0.);
                kwj.set(0, 0, 1, 0.);
                kwj.set(0, 1, 0, 0.);
                kwj.set(0, 1, 1, 0.);

            }
            
        }
    }

    return degree;
}


int CoreyQuadPermeability::QuadPermeabilityWater_jet(const WaveState &u, int degree, JetMatrix &kwj) const {
    double sw = u(0);
    double so = u(1);
    double sg = 1.0 - sw - so;

    if (degree >= 0){

	//double kw = sw * sw;    // Colocar parte linear
        //kwj.set(0, kw);


	/*   Para a parte linear, fazer:
                swcnw = sw - cnw
	        kw    = (lw + (1. - lw)*swcnw)*swcnw
	*/


	double swcnw = sw - cnw_;
	double kw    = (lw_ + (1. - lw_) * swcnw) * swcnw;
        
        kwj.set(0, kw);
        

        if (degree >= 1) {

	    double dkw_dsw = 2. * (1. - lw_) * swcnw + lw_;
            double dkw_dso = 0.0;
            
            kwj.set(0, 0, dkw_dsw);
            kwj.set(0, 1, dkw_dso);
            
            
            if (degree >= 2) {

		double d2kw_dsw2   = 2. * (1. - lw_);
                double d2kw_dswdso = 0.0;
                double d2kw_dsodsw = 0.0;
                double d2kw_dso2   = 0.0;
                
                kwj.set(0, 0, 0, d2kw_dsw2);
                kwj.set(0, 0, 1, d2kw_dswdso);
                kwj.set(0, 1, 0, d2kw_dsodsw);
                kwj.set(0, 1, 1, d2kw_dso2);
            }
            
            
        }
    }


    return degree;
}
// --------------------------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------------------------
int CoreyQuadPermeability::ZeroPermeabilityOil_jet(const WaveState &u, int degree, JetMatrix &koj) const {

    if (degree >= 0){

	koj.set(0, 0.);
        
        if (degree >= 1) {

            koj.set(0, 0, 0.);
            koj.set(0, 1, 0.);
            
            if (degree >= 2) {

                koj.set(0, 0, 0, 0.);
                koj.set(0, 0, 1, 0.);
                koj.set(0, 1, 0, 0.);
                koj.set(0, 1, 1, 0.);
            }
            
        }
    }

    return degree;

}


int CoreyQuadPermeability::QuadPermeabilityOil_jet(const WaveState &u, int degree, JetMatrix &koj) const {
    double sw = u(0);
    double so = u(1);
    double sg = 1.0 - sw - so;

    if (degree >= 0){
        //double ko = so * so;    // Colocar parte linear
        //koj.set(0, ko);


	/*   Para a parte linear, fazer:
                socno = so - cno
	        ko    = (lo + (1. - lo)*socno)*socno
	*/

	double socno = so - cno_;
	double ko    = (lo_ + (1. - lo_) * socno) * socno;

	koj.set(0, ko);
        
        if (degree >= 1) {

            double dko_dsw = 0.0;
            double dko_dso = 2. * (1. - lo_) * socno + lo_;
            
            koj.set(0, 0, dko_dsw);
            koj.set(0, 1, dko_dso);
            
            
            if (degree >= 2) {

                double d2ko_dsw2   = 0.0;
                double d2ko_dswdso = 0.0;
                double d2ko_dsodsw = 0.0;
                double d2ko_dso2   = 2. * (1. - lo_);
                
                koj.set(0, 0, 0, d2ko_dsw2);
                koj.set(0, 0, 1, d2ko_dswdso);
                koj.set(0, 1, 0, d2ko_dsodsw);
                koj.set(0, 1, 1, d2ko_dso2);
            }
            
            
        }
    }

    return degree;
}
// --------------------------------------------------------------------------------------------------------


// --------------------------------------------------------------------------------------------------------
int CoreyQuadPermeability::ZeroPermeabilityGas_jet(const WaveState &u, int degree, JetMatrix &kgj) const {

    if (degree >= 0){

        kgj.set(0, 0.);
        
        if (degree >= 1) {

            kgj.set(0, 0, 0.);
            kgj.set(0, 1, 0.);
            
            if (degree >= 2) {

                kgj.set(0, 0, 0, 0.);
                kgj.set(0, 0, 1, 0.);
                kgj.set(0, 1, 0, 0.);
                kgj.set(0, 1, 1, 0.);
            }
            
        }
    }

    return degree;
}


int CoreyQuadPermeability::QuadPermeabilityGas_jet(const WaveState &u, int degree, JetMatrix &kgj) const {
    double sw = u(0);
    double so = u(1);
    double sg = 1.0 - sw - so;

    if (degree >= 0){
        //double kg = sg * sg;    // Colocar parte linear
        //kgj.set(0, kg);


	/*   Para a parte linear, fazer:
                sgcng = sg - cng
	        kg    = (lg + (1. - lg)*sgcng)*sgcng
	*/


	double sgcng = sg - cng_;
	double kg    = (lg_ + (1. - lg_) * sgcng) * sgcng;

        kgj.set(0, kg);
        
        if (degree >= 1) {

            double dkg_dsw = -2. * (1. - lg_) * sgcng - lg_;
            double dkg_dso = -2. * (1. - lg_) * sgcng - lg_;
            
            kgj.set(0, 0, dkg_dsw);
            kgj.set(0, 1, dkg_dso);
            
            
            if (degree >= 2) {

                double d2kg_dsw2   = 2. * (1. - lg_);
                double d2kg_dswdso = 2. * (1. - lg_);
                double d2kg_dsodsw = 2. * (1. - lg_);
                double d2kg_dso2   = 2. * (1. - lg_);
                
                kgj.set(0, 0, 0, d2kg_dsw2);
                kgj.set(0, 0, 1, d2kg_dswdso);
                kgj.set(0, 1, 0, d2kg_dsodsw);
                kgj.set(0, 1, 1, d2kg_dso2);
            }
            
            
        }
    }


    return degree;
}
// --------------------------------------------------------------------------------------------------------


