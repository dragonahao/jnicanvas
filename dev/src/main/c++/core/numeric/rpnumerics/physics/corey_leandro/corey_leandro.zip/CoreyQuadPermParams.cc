/*
 * IMPA - Fluid Dynamics Laboratory
 *
 * RPn Project
 *
 * @(#) CoreyQuadPermParams.cc
 */

/*
 * ---------------------------------------------------------------
 * Includes:
 */
#include "CoreyQuadPermParams.h"
#include <iostream>
using namespace std;

/*
 * ---------------------------------------------------------------
 * Definitions:
 */

CoreyQuadPermParams::CoreyQuadPermParams(double cnw, double cng, double cno,
                                 double lw, double lg, double lo) : comp(new RealVector(6))/*, comp(new RealVector(6))*/ {

    comp->component(0) = cnw;
    comp->component(1) = cng;
    comp->component(2) = cno;

    comp->component(3) = lw;
    comp->component(4) = lg;
    comp->component(5) = lo;
}

CoreyQuadPermParams::CoreyQuadPermParams(const RealVector & permVector) : comp(new RealVector(6)) {

    for (int i = 0; i < permVector.size(); i++) {
        comp->component(i) = permVector(i);
    }

}

CoreyQuadPermParams::CoreyQuadPermParams() : comp(new RealVector(6)) {
    reset();
}

CoreyQuadPermParams::CoreyQuadPermParams(const CoreyQuadPermParams & copy) : comp(new RealVector(copy.comp)) {
}

CoreyQuadPermParams::~CoreyQuadPermParams() {
    delete comp;
}

void CoreyQuadPermParams::reset() {

    comp->component(0) = 0.0;
    comp->component(1) = 0.0;
    comp->component(2) = 0.0;

    comp->component(3) = 0.0;
    comp->component(4) = 0.0;
    comp->component(5) = 0.0;
}

double CoreyQuadPermParams::component(int i) {
    return comp->component(i);
}


