/*
 * IMPA - Fluid Dynamics Laboratory
 *
 * RPn Project
 *
 * @(#) CoreyQuadPermParams.h
 */

#ifndef _CoreyQuadPermParams_H
#define _CoreyQuadPermParams_H

/*
 * ---------------------------------------------------------------
 * Includes:
 */

#include "RealVector.h"
#include "WaveState.h"
#include "JetMatrix.h"

/*
 * ---------------------------------------------------------------
 * Definitions:
 */


class CoreyQuadPermParams {
private:
    RealVector * comp;

public:

    CoreyQuadPermParams(double cnw, double cng, double cno,
                        double lw, double lg,double lo);

    CoreyQuadPermParams();
    CoreyQuadPermParams (const RealVector &);
    CoreyQuadPermParams(const CoreyQuadPermParams &);
    virtual ~CoreyQuadPermParams();

    void reset();

    double component(int);

    const RealVector & params() const;
};

inline const RealVector & CoreyQuadPermParams::params()const {
    return *comp;
}


#endif //! _CoreyQuadPermParams_H

