#include "Three_Phase_Boundary.h"

Three_Phase_Boundary::Three_Phase_Boundary(){
    pmin = new RealVector(2);
    pmin->component(0) = 0.0;
    pmin->component(1) = 0.0;

    pmax = new RealVector(2);
    pmax->component(0) = 1.0;
    pmax->component(1) = 1.0;
}

Three_Phase_Boundary::~Three_Phase_Boundary(){
    delete pmax;
    delete pmin;
}

bool Three_Phase_Boundary::inside(const RealVector &p) const {
    return ((p.component(0) >= 0.0 && p.component(1) >= 0.0) && 
            (p.component(0) + p.component(1) <= 1.0)
           );
}

bool Three_Phase_Boundary::inside(const double *p) const {
    return ((p[0] >= 0.0 && p[1] >= 0.0) && 
            (p[0] + p[1] <= 1.0)
           );
}

Boundary * Three_Phase_Boundary::clone() const {
    return new Three_Phase_Boundary();
}

const RealVector& Three_Phase_Boundary::minimums(void) const {
    return *pmin;
}

const RealVector& Three_Phase_Boundary::maximums(void) const {
    return *pmax;
}

RealVector Three_Phase_Boundary::intersect(RealVector &p1, RealVector &p2) const {
    return RealVector(2);
}

const char * Three_Phase_Boundary::boundaryType() const {
    return "Three_Phase_Boundary";
}

