#ifndef _THREE_PHASE_BOUNDARY_
#define _THREE_PHASE_BOUNDARY_

#include "Boundary.h"
#include "RealVector.h"

class Three_Phase_Boundary : public Boundary {
    protected:
        RealVector *pmin, *pmax;
    public:
        Three_Phase_Boundary();
        ~Three_Phase_Boundary();

        bool inside(const RealVector &p) const;
        bool inside(const double *p) const;

        Boundary* clone() const;

        const RealVector& minimums(void) const;
        const RealVector& maximums(void) const;


        RealVector intersect(RealVector &p1, RealVector &p2) const;

        const char* boundaryType() const;
};

#endif // _THREE_PHASE_BOUNDARY_

